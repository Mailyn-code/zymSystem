let apiUrl = "http://localhost:8082/api/productos";

const contenedor = document.querySelector("tbody");
let idRegistro;
let resultados = "";

const getProductos = async () => {
  try {
    const response = await fetch(apiUrl);
    const productos = await response.json();
    const { data, success } = productos;

    data.forEach((productos) => {
      const {
        COD_PRODUCTO,
        COD_DE_BARRA_PRODUCTO,
        IMG_PRODUCTO,
        NOM_PRODUCTO,
       DES_PRODUCTO,
    DES_CATEGORIA,
    DES_MARCA,
     DES_PRESENTACION,
    NOM_SUCURSAL,
    COD_CATEGORIA,
COD_MARCA,
COD_PRESENTACION,
COD_USUARIO,
COD_SUCURSAL
    
      } = productos;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(productos)}</td>
       <td>${COD_PRODUCTO}</td>
       <td>${NOM_PRODUCTO}</td>
     <td>${DES_PRODUCTO}</td>
     <td>${DES_CATEGORIA}</td>
     <td>${DES_MARCA}</td>
     <td>${DES_PRESENTACION}</td>
     <td>${NOM_SUCURSAL}</td>
     <td>
     <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
     Actualizar
        </i>
      </button>
       </td>
     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};


getProductos ();

