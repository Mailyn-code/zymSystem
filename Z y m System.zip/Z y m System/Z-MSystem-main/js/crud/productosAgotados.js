let apiUrl = "http://localhost:8082/api/productosAgotados";

const contenedor = document.querySelector("tbody");


let resultados = "";


const getProductosAgotados = async () => {
  try {
    const response = await fetch(apiUrl);
    const agotados = await response.json();
    const { data, success } = agotados;

   
    data.forEach((agotado) => {
     
      const {
        COD_INVENTARIO,
        COD_PRODUCTO,
        NOM_PRODUCTO,
        ENTRADA_PRODUCTO,
        SALIDA_PRODUCTO,
        STOCK,
        PRECIO_VENTA,
        TOTAL_INVENTARIO,
        COD_SUCURSAL,
        NOM_SUCURSAL
       
      } = agotado;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(agotado)}</td>
      <td>${COD_PRODUCTO}</td>
      <td>${NOM_PRODUCTO}</td>
      <td>${ENTRADA_PRODUCTO}</td>
      <td>${SALIDA_PRODUCTO}</td>
      <td>${STOCK}</td>
      <td>${PRECIO_VENTA}</td>
      <td>${TOTAL_INVENTARIO}</td>
      <td>${NOM_SUCURSAL}</td>
     
     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};


getProductosAgotados();