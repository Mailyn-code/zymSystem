let apiUrl = "http://localhost:8082/api/productosPorVencer";

const contenedor = document.querySelector("tbody");


let resultados = "";


const getProductosPorVencer = async () => {
  try {

    const response = await fetch(apiUrl);
    const almacenes = await response.json();
    const { data, success } = almacenes;

    console.log(data)
    data.forEach((almacen) => {
        console.log(almacen)
      const {
        NOM_PRODUCTO,
        CODIGO_BARRA_PRODUCTO,
        DESC_PRODUCTO,
        CODIGO_LOTE,
        EXISTENCIA_LOTE,
        FECHA_CADUCIDAD,
        NOM_SUCURSAL,
        
      } = almacen;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(almacen)}</td>
       <td>${NOM_PRODUCTO}</td>
   <td>${CODIGO_BARRA_PRODUCTO}</td>
     <td>${DESC_PRODUCTO}</td>
     <td>${CODIGO_LOTE}</td>
     <td>${EXISTENCIA_LOTE}</td>
     <td>${FECHA_CADUCIDAD}</td>
     <td>${NOM_SUCURSAL}</td>

     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};


getProductosPorVencer();