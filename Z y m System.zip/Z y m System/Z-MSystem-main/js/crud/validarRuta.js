//history.forward();

const menu = () => {
  const role = window.localStorage.getItem("role");



  const navBar = document.querySelector(".navbar");
  const template = `<!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.html">Z&M System</a>
            </div>

            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <ul class="nav navbar-right navbar-top-links">
                <li class="dropdown navbar-inverse">

                </li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> Cerrar Sesion <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu dropdown-user">

                        <li class="divider"></li>
                        <li><a onclick="cerrarSesion()"><i class="fa fa-sign-out fa-fw"></i> Cerrar Sesion</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <center>
                        <h3 class="tittle-menu">Bienvenido(a)</h3>
                    </center>
                    <ul class="nav nav-container" id="side-menu">

                        <li>
                            <a href="index.html" class="active custumer-a"><i class="fa fa-dashboard fa-fw"></i>
                                Dashboard</a>
                        </li>
                        <li>
                            <a href="#" class="custumer-a"><i class="fa fa-bar-chart-o fa-fw"></i> Productos<span
                                    class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="categorias.html" class="custumer-a">Categorias</a>
                                </li>
                                <li>
                                    <a href="marcas.html" class="custumer-a">Marca</a>
                                </li>
                                <li>
                                    <a href="presentacion.html" class="custumer-a">Presentación</a>
                                </li>
                                <li>
                                    <a href="productos.html" class="custumer-a">Productos</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#" class="custumer-a"><i class="fa fa-bar-chart-o fa-fw"></i> Compras<span
                                    class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="compras.html" class="custumer-a">compras</a>
                                </li>

                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#" class="custumer-a"><i class="fa fa-bar-chart-o fa-fw"></i> Ventas<span
                                    class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="ventas.html" class="custumer-a">Ventas</a>
                                </li>
                                <li>
                                    <a href="factura.html" class="custumer-a">Factura</a>
                                </li>
                                <li>
                                    <a href="formaDePago.html" class="custumer-a">Forma de pago</a>
                                </li>
                            
                            </ul>
                            </li>
${
  role === "ADMINISTRADOR"
    ? ` <li>
                            <a href="#" class="custumer-a"><i class="fa fa-bar-chart-o fa-fw"></i>
                                Personas<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="EMAIL.html" class="custumer-a">Email</a>
                                </li>
                                <li>
                                    <a href="direccion.html" class="custumer-a">Dirección</a>
                                </li>
                                <li>
                                    <a href="telefono.html" class="custumer-a">Telefóno</a>
                                </li>
                                <li>
                                    <a href="personas.html" class="custumer-a">Personas</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        
                         <li>
                            <a href="#" class="custumer-a"><i class="fa fa-bar-chart-o fa-fw"></i>
                                Usuarios<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="usuario.html" class="custumer-a">usuario</a>
                                </li>
                                <li>
                                    <a href="roles.html" class="custumer-a">Rol</a>
                                </li>
                    
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        `
    : ``
}

                        <li>
                            <a href="#" class="custumer-a"><i class="fa fa-bar-chart-o fa-fw"></i>
                                Inventario<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="inventario.html" class="custumer-a">Inventario</a>
                                </li>
                                <li>
                                    <a href="almacenProducto.html" class="custumer-a">Almacen producto</a>
                                </li>
                                
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>

                        <li>
                        <a href="#" class="custumer-a"><i class="fa fa-bar-chart-o fa-fw"></i>
                        Reportes<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="productosAgotados.html" class="custumer-a">Productos Agotados</a>
                        </li>
                        <li>
                            <a href="productosPorVencer.html" class="custumer-a">Productos por Vencer</a>
                        </li>
                        
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
                <li>
                <a href="#" class="custumer-a"><i class="fa fa-bar-chart-o fa-fw"></i>
                Configuración<span class="fa arrow"></span></a>
            <ul class="nav nav-second-level">
                
                <li>
                    <a href="almacenProducto.html" class="custumer-a">Ajustes</a>
                </li>
                
            </ul>
            <!-- /.nav-second-level -->
        </li>
        <li>
        <a href="#" class="custumer-a"><i class="fa fa-bar-chart-o fa-fw"></i>
        Derechos Reservados<span class="fa arrow"></span></a>
    <ul class="nav nav-second-level">
        
        <li>
            <a href="almacenProducto.html" class="custumer-a"></a>
        </li>
        
    </ul>
    <!-- /.nav-second-level -->
</li>

                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>`;

  navBar.innerHTML = template;
};

const getAuth = async () => {
  const firebaseConfig = {
    apiKey: "AIzaSyCJ3P--EOC3hmCEzlWzUjUhJgn_VksOnBE",
    authDomain: "msystem-9d38e.firebaseapp.com",
    projectId: "msystem-9d38e",
    storageBucket: "msystem-9d38e.appspot.com",
    messagingSenderId: "978189138302",
    appId: "1:978189138302:web:d7ac63b1ffbc096c0f1b2f",
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  await firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      console.log("logueado");
    } else {
      window.location.href = "login.html";
    }
  });
};

const cerrarSesion = () => {
  firebase
    .auth()
    .signOut()
    .then(() => {
      console.log("exito");
      // Sign-out successful.
    })
    .catch((error) => {
      // An error happened.
    });
};

getAuth();
menu();
