let apiUrl = "http://localhost:8082/api/presentacion";

const contenedor = document.querySelector("tbody");
let idRegistro;
let {descripcionPresentacion,codigoSucursal,unidadMedicion,cantidadMedicion} =
document.forms["formularioPresentacion"];
const btnGuardar = document.querySelector(".contentBtnGuardar");

let resultados = "";

const getPresentacion = async () => {
  try {
    const response = await fetch(apiUrl);
    const presentaciones = await response.json();
    const { data, success } = presentaciones;

    data.forEach((presentacion) => {
      const {
        COD_PRESENTACION,
        DES_PRESENTACION,
        UNIDAD_DE_MEDICION,
        CANT_DE_MEDICION,
        NOM_SUCURSAL
  
      } = presentacion;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(presentacion)}</td>
       <td>${COD_PRESENTACION}</td>
   <td>${DES_PRESENTACION}</td>
     <td>${UNIDAD_DE_MEDICION}</td>
     <td>${CANT_DE_MEDICION}</td>
     <td>${NOM_SUCURSAL}</td>
     <td>
     <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
     Actualizar
        </i>
      </button>
       </td>
     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};

const postPresentacion= async () => {
  try {

    if(descripcionPresentacion.value===""||codigoSucursal.value===""||unidadMedicion.value===""||
    cantidadMedicion.value==="" ){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      desPresentacion:descripcionPresentacion.value,
        codSucursal:codigoSucursal.value,
        unidadMedicion:unidadMedicion.value,
        canMedicion:cantidadMedicion.value
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        desPresentacion:descripcionPresentacion.value,
        codSucursal:codigoSucursal.value,
        unidadMedicion:unidadMedicion.value,
        canMedicion:cantidadMedicion.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }
};

////////////////////////
const putPresentacion= async () => {
  try {
  
    let body;
  
   
      body = {
        codPresentacion:idRegistro,
        desPresentacion:descripcionPresentacion.value,
        unidadMedicion:unidadMedicion.value,
        canMedicion:cantidadMedicion.value
        
       
      };
    
     

    console.log(body)
    const requestOptions = {
      method: "PUT",
      body: JSON.stringify(body),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
   location.reload();
  } catch (error) {
    console.log(error.message);
  }
};



const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postPresentacion()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro
on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {
 
       COD_PRESENTACION,
        DES_PRESENTACION,
        UNIDAD_DE_MEDICION,
        CANT_DE_MEDICION,
  } = JSON.parse(id);

  descripcionPresentacion.value=DES_PRESENTACION;
  unidadMedicion.value=UNIDAD_DE_MEDICION;
  cantidadMedicion.value=CANT_DE_MEDICION;
  idRegistro=COD_PRESENTACION;

  btnGuardar.innerHTML = `  <button onclick="putPresentacion()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});

const getPresentacionSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/sucursales");
  const sucursales = await response.json();
  const { data, success } = sucursales;
  const contenedorSelect = document.querySelector("#codigoSucursal");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((sucursal) => {
    const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;

    resultadosSelect += `
 
   <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

 getPresentacion();
 getPresentacionSelect();