
let apiUrl = "http://localhost:8082/api/telefonos";

const contenedor = document.querySelector("tbody");
let idRegistro;
let {codigoPersona,numeroTelefono,tipoTelefono} =
document.forms["formularioTelefono"];

const btnGuardar = document.querySelector(".contentBtnGuardar");
let resultados = "";

const getTelefonos = async () => {
  try {
    const response = await fetch(apiUrl);
    const telefonos = await response.json();
    const { data, success } = telefonos;

    data.forEach((telefono) => {
      const {
     COD_TELEFONO,   
     PRIMER_NOM_PERSONA,
     PRIMER_APELLIDO_PERSONA,
     NUM_TELEFONO,
     TIPO_TELEFONO,
      } = telefono;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(telefono)}</td>
      <td>${COD_TELEFONO}</td>
   <td>${PRIMER_NOM_PERSONA }     ${ PRIMER_APELLIDO_PERSONA}</td>
     <td>${NUM_TELEFONO}</td>
     <td>${TIPO_TELEFONO}</td>
     <td>
     <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
     Actualizar
        </i>
      </button>
       </td>
     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};

const postTelefonos = async () => {
  try {

    if(codigoPersona.value===""||numeroTelefono.value===""||tipoTelefono.value===""){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      numTel:numeroTelefono.value,
      tipoTel:tipoTelefono.value,
      codPersona:codigoPersona.value
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        numTel:numeroTelefono.value,
        tipoTel:tipoTelefono.value,
        codPersona:codigoPersona.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }

};

const getPersonasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/personas");
  const personas = await response.json();
  const { data, success } = personas;
  const contenedorSelect = document.querySelector("#codigoPersona");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((persona) => {
    const { COD_PERSONA,PRIMER_NOM_PERSONA,	PRIMER_APELLIDO_PERSONA} = persona;

    resultadosSelect += `
 
   <option value="${COD_PERSONA}">${PRIMER_NOM_PERSONA}  ${PRIMER_APELLIDO_PERSONA} </option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};


const putTelefonos= async (id = null, estado = null) => {
  try {

    console.log(idRegistro)
    let body;
    if (id) {
      const {

        COD_PERSONA,
        NUM_TELEFONO,
        TIPO_TELEFONO
      } = JSON.parse(id);

      body = {
        codPersona:codigoPersona.value,
        numTel:numeroTelefono.value,
        tipoTel:tipoTelefono.value
  
      
      };
    } else {
      body = {
        codPersona:codigoPersona.value,
        numTel:numeroTelefono.value,
        tipoTel:tipoTelefono.value

      };
    }

    
    console.log(body)
    const requestOptions = {
      method: "PUT",
      body: JSON.stringify(body),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
   location.reload();
  } catch (error) {
    console.log(error.message);
  }
};



const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postTelefonos()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro
on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {
    COD_PERSONA,
    NUM_TELEFONO,
    TIPO_TELEFONO
  } = JSON.parse(id);
  codigoPersona.value=COD_PERSONA;
  numeroTelefono.value=NUM_TELEFONO;
  tipoTelefono.value=TIPO_TELEFONO;
  


  btnGuardar.innerHTML = `  <button onclick="putTelefonos()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});


getTelefonos();
getPersonasSelect();