let apiUrl = "http://localhost:8082/api/roles";

const contenedor = document.querySelector("tbody");
let {descripcionRol,sucursal } =
document.forms["formularioRoles"];
let resultados = "";

  const getRoles= async() => {
    try {
      
    
    const response = await fetch(apiUrl);
    const rol = await response.json();
    const { data, success } = rol;
  
    data.forEach((rol) => {
      const {
        DES_ROL,
        COD_ROL,
        NOM_SUCURSAL,
      
       
      } = rol;
  
      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(rol)}</td>
   
      <td>${COD_ROL}</td>
       <td>${DES_ROL}</td>
       
     </tr>
                    `;
    }); 
    contenedor.innerHTML = resultados;
  
  
  } catch (error) {
      
  }
  };
  
  const postRoles= async () => {
    try {

        if(descripcionRol.value===""||sucursal.value===""){
        alertify.alert("No, se permiten campos Vacíos", function () { });
      
      }else{ 
         await firebase
         
      console.log("hola",{
        desRol:descripcionRol.value,
          codSucursal:sucursal.value
        
      })
      const requestOptions = {
        method: "POST",
        body: JSON.stringify({
          desRol:descripcionRol.value,
          codSucursal:sucursal.value
          
        }),
        headers: { "Content-type": "application/json; charset=UTF-8" },
      };
  
      const response = await fetch(apiUrl, requestOptions);
      const data = await response.json();
      console.log(data);
      location.reload();
         
          setTimeout(() => {
            location.reload();
          }, 3000);
        }
  
    } catch (error) {
      console.log(error);
    }

  };
  

  const getSucursalSelect= async() => {
    try {
      
    const response = await fetch("http://localhost:8082/api/sucursales");
    const sucursales = await response.json();
    const { data, success } = sucursales;
    const contenedorSelect = document.querySelector("#sucursal");
    let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
    data.forEach((sucursal) => {
      const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;
  
      resultadosSelect += `
   
     <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
    
                  `;
    });
    
    contenedorSelect.innerHTML = resultadosSelect;
   
    
  } catch (error) {
      
  }
  };

  getRoles();
  getSucursalSelect();