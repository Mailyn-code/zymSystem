
let apiUrl = "http://localhost:8082/api/email";

const contenedor = document.querySelector("tbody");

let idRegistro;
let {descripcionEmail,nombrePersona } =
document.forms["formularioEmail"];
const btnGuardar = document.querySelector(".contentBtnGuardar");

let resultados = "";

const getEmail = async () => {
  try {
    const response = await fetch(apiUrl);
    const emails = await response.json();
    const { data, success } = emails;

    data.forEach((email) => {
      const {
     COD_EMAIL,   
     DES_EMAIL,
     PRIMER_NOM_PERSONA, SEGUNDO_NOM_PERSONA,
      } = email;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(email)}</td>
      <td>${COD_EMAIL}</td>
   <td>${DES_EMAIL}</td>
     <td>${PRIMER_NOM_PERSONA}   ${SEGUNDO_NOM_PERSONA}</td>
     <td>
     <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
     Actualizar
        </i>
      </button>
       </td>
     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};

const postEmail = async () => {
  try {

    if(descripcionEmail.value==="" || nombrePersona.value==="" ){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      desEmail:descripcionEmail.value,
        codPersona:nombrePersona.value
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
      
        desEmail:descripcionEmail.value,
        codPersona:nombrePersona.value
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }

};



const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postEmail()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro
on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {

    COD_EMAIL,   
    DES_EMAIL,
    COD_PERSONA,
  } = JSON.parse(id);

  descripcionEmail.value=DES_EMAIL;
  nombrePersona.value=COD_PERSONA;
  idRegistro=COD_EMAIL;

  btnGuardar.innerHTML = `  <button onclick="putEmail()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});

const getPersonasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/personas");
  const personas = await response.json();
  const { data, success } = personas;
  const contenedorSelect = document.querySelector("#nombrePersona");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((persona) => {
    const { COD_PERSONA,PRIMER_NOM_PERSONA,	PRIMER_APELLIDO_PERSONA} = persona;

    resultadosSelect += `
 
   <option value="${COD_PERSONA}">${PRIMER_NOM_PERSONA}  ${PRIMER_APELLIDO_PERSONA} </option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};
 getEmail();
 getPersonasSelect();