let apiUrl = "http://localhost:8082/api/ventas";

const contenedor = document.querySelector("tbody");

let resultados = "";

const getVentas= async() => {
  try {
    const role = window.localStorage.getItem("role");
    const codigoUsuario = window.localStorage.getItem("codigoUsuario");
console.log({role,codigoUsuario})
    const url =
      role === "Administrador"
        ? apiUrl
        : `${apiUrl}?idUsuario=${codigoUsuario}`;


        const response = await fetch(url);
        const ventas = await response.json();
        const { data, success } = ventas;
  
        data.forEach((venta) => {
          const { COD_VENTA, COD_FACTURA, TOT_VENTA, FEC_VENTA, NOM_SUCURSAL } =
            venta;
    
          resultados += `

    <tr>
    <td class="dataItem">${JSON.stringify(venta)}</td>
   
    <td>${COD_FACTURA}</td>
     <td>${TOT_VENTA}</td>
     <td>${FEC_VENTA}</td>
   <td>${NOM_SUCURSAL}</td>
   <td>
   
  
 </tr>
                `;
              
});

contenedor.innerHTML = resultados;
} catch (error) {
console.log(error);
}
};


getVentas();