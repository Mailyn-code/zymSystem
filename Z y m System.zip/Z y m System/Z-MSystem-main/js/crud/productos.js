
let apiUrl = "http://localhost:8082/api/productos";

const contenedor = document.querySelector("tbody");
let idRegistro;
let {
  codigoBarraProducto,
  nombreProducto,descripcionProducto,imgProducto,codigoCategoria,codigoMarca,codigoPresentacion,codigoUsuario,codigoSucursal
} =document.forms["formularioProductos"];
const btnGuardar = document.querySelector(".contentBtnGuardar");
let resultados = "";

const getProductos = async () => {
  try {
    const response = await fetch(apiUrl);
    const productos = await response.json();
    const { data, success } = productos;

    data.forEach((productos) => {
      const {
        COD_PRODUCTO,
        COD_DE_BARRA_PRODUCTO,
        IMG_PRODUCTO,
        NOM_PRODUCTO,
       DES_PRODUCTO,
    DES_CATEGORIA,
    DES_MARCA,
     DES_PRESENTACION,
    NOM_SUCURSAL,
    COD_CATEGORIA,
COD_MARCA,
COD_PRESENTACION,
COD_USUARIO,
COD_SUCURSAL
    
      } = productos;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(productos)}</td>
       <td>${COD_PRODUCTO}</td>
       <td>${NOM_PRODUCTO}</td>
     <td>${DES_PRODUCTO}</td>
     <td>${DES_CATEGORIA}</td>
     <td>${DES_MARCA}</td>
     <td>${DES_PRESENTACION}</td>
     <td>${NOM_SUCURSAL}</td>
     <td>
     <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
     Actualizar
        </i>
      </button>
       </td>
     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};

const postProductos= async () => {
  try {

    if(codigoBarraProducto.value===""||
      nombreProducto.value===""||descripcionProducto.value===""||
      codigoCategoria.value===""||codigoMarca.value===""||codigoPresentacion.value===""||
      codigoUsuario.value===""||codigoSucursal.value===""){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      codBarraProducto:codigoBarraProducto.value,
      nomProducto:nombreProducto.value,
      desProducto:descripcionProducto.value,
      imgProducto:imgProducto.value,
      codUsuario:codigoUsuario.value,
      codCategoria:codigoCategoria.value,
      codMarca:codigoMarca.value,
      codPresentacion:codigoPresentacion.value,
      codSucursal:codigoSucursal.value
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        codBarraProducto:codigoBarraProducto.value,
        nomProducto:nombreProducto.value,
        desProducto:descripcionProducto.value,
        imgProducto:imgProducto.value,
        codUsuario:codigoUsuario.value,
        codCategoria:codigoCategoria.value,
        codMarca:codigoMarca.value,
        codPresentacion:codigoPresentacion.value,
        codSucursal:codigoSucursal.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }


};

////////////////////////
const putProductos= async () => {
  try {
  
    let body;

      body = {
        codProducto:idRegistro,
        codBarraProducto:codigoBarraProducto.value,
        nomProducto:nombreProducto.value,
        desProducto:descripcionProducto.value,
        imgProducto:imgProducto.value,
        codUsuario:codigoUsuario.value,
        codCategoria:codigoCategoria.value,
        codMarca:codigoMarca.value,
        codPresentacion:codigoPresentacion.value,
        codSucursal:codigoSucursal.value
       
      };
    
     

    console.log(body)
    const requestOptions = {
      method: "PUT",
      body: JSON.stringify(body),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
  location.reload();
  } catch (error) {
    console.log(error.message);
  }
};



const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postProductos()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro
on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {

    COD_PRODUCTO,
    COD_DE_BARRA_PRODUCTO,
    NOM_PRODUCTO,
   DES_PRODUCTO,
   IMG_PRODUCTO,
COD_CATEGORIA,
COD_MARCA,
COD_PRESENTACION,
COD_USUARIO,
COD_SUCURSAL
  } = JSON.parse(id);

  codigoBarraProducto.value=COD_DE_BARRA_PRODUCTO;
  nombreProducto.value=NOM_PRODUCTO;
  descripcionProducto.value=DES_PRODUCTO;
  imgProducto.value=IMG_PRODUCTO;
  codigoCategoria.value=COD_CATEGORIA;
  codigoMarca.value=COD_MARCA;
  codigoPresentacion.value=COD_PRESENTACION;
  codigoUsuario.value=COD_USUARIO;
  codigoSucursal.value=COD_SUCURSAL;
  idRegistro=COD_PRODUCTO;

  btnGuardar.innerHTML = `  <button onclick="putProductos()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});

const getSucursalSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/sucursales");
  const sucursales = await response.json();
  const { data, success } = sucursales;
  const contenedorSelect = document.querySelector("#codigoSucursal");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((sucursal) => {
    const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;

    resultadosSelect += `
 
   <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getMarcasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/marcas");
  const marcas = await response.json();
  const { data, success } = marcas;
  const contenedorSelect = document.querySelector("#codigoMarca");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((marca) => {
    const { COD_MARCA, DES_MARCA } = marca;

    resultadosSelect += `
 
   <option value="${COD_MARCA}">${DES_MARCA}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getPresentacionSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/presentacion");
  const presentaciones = await response.json();
  const { data, success } = presentaciones;
  const contenedorSelect = document.querySelector("#codigoPresentacion");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((presentacion) => {
    const { COD_PRESENTACION, DES_PRESENTACION } = presentacion;

    resultadosSelect += `
 
   <option value="${COD_PRESENTACION}">${DES_PRESENTACION}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getCategoriaSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/categorias");
  const categorias = await response.json();
  const { data, success } = categorias;
  const contenedorSelect = document.querySelector("#codigoCategoria");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((categoria) => {
    const { COD_CATEGORIA, DES_CATEGORIA } = categoria;

    resultadosSelect += `
 
   <option value="${COD_CATEGORIA}">${DES_CATEGORIA}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getUsuarioSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/usuarios");
  const categorias = await response.json();
  const { data, success } = categorias;
  const contenedorSelect = document.querySelector("#codigoUsuario");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((usuario) => {
    const { COD_USUARIO, USUARIO_USR } = usuario;

    resultadosSelect += `
 
   <option value="${COD_USUARIO}">${USUARIO_USR}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

getProductos ();
getSucursalSelect();
getMarcasSelect();
getPresentacionSelect();
getCategoriaSelect();
getUsuarioSelect();
