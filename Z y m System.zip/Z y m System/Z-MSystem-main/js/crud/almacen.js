let apiUrl = "http://localhost:8082/api/almacen";

const contenedor = document.querySelector("tbody");


let resultados = "";


const getAlmacen = async () => {
  try {
    const role = window.localStorage.getItem("role");
    const codigoUsuario = window.localStorage.getItem("codigoUsuario");

    const url =
      role === "Administrador"
        ? apiUrl
        : `${apiUrl}?idUsuario=${codigoUsuario}`;


    const response = await fetch(url);
    const almacenes = await response.json();
    const { data, success } = almacenes;

    console.log(data)
    data.forEach((almacen) => {
        console.log(almacen)
      const {
        NOM_PRODUCTO,
        CODIGO_BARRA_PRODUCTO,
        DESC_PRODUCTO,
        CODIGO_LOTE,
        EXISTENCIA_LOTE,
        FECHA_CADUCIDAD,
        NOM_SUCURSAL,
        
      } = almacen;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(almacen)}</td>
       <td>${NOM_PRODUCTO}</td>
   <td>${CODIGO_BARRA_PRODUCTO}</td>
     <td>${DESC_PRODUCTO}</td>
     <td>${CODIGO_LOTE}</td>
     <td>${EXISTENCIA_LOTE}</td>
     <td>${FECHA_CADUCIDAD}</td>
     <td>${NOM_SUCURSAL}</td>

     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};


getAlmacen();