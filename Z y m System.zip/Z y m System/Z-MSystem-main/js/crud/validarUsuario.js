let apiUrl = "http://localhost:8082/api/validarUsuario";

const firebaseConfig = {
  apiKey: "AIzaSyCJ3P--EOC3hmCEzlWzUjUhJgn_VksOnBE",
  authDomain: "msystem-9d38e.firebaseapp.com",
  projectId: "msystem-9d38e",
  storageBucket: "msystem-9d38e.appspot.com",
  messagingSenderId: "978189138302",
  appId: "1:978189138302:web:d7ac63b1ffbc096c0f1b2f",
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

let { usuario, password } = document.forms["formularioLogin"];

let { email } = document.forms["formularioReset"];
let resultados = "";

const getValidarUsuario = async () => {
  try {
    const userCredential = await firebase
      .auth()
      .signInWithEmailAndPassword(usuario.value, password.value);

    let apiUrl = "http://localhost:8082/api/validarUsuario";
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        email: userCredential.user.email,
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const { data } = await response.json();
    const [user] = data;
    const { DES_ROL, COD_USUARIO } = user;

    window.localStorage.setItem("role", DES_ROL);
    window.localStorage.setItem("codigoUsuario", COD_USUARIO);
    window.location.href = "index.html";
  } catch (error) {
    
    if (error.code === "auth/wrong-password") {
      alertify.alert("Usuario ó contraseña Incorrecta", function () { });
    } else if (error.code === "auth/invalid-email") {
      alertify.alert("Ingrese una direccion de correo valida", function () { });
    }else if( usuario.value===""|| password.value===""){
      alertify.alert("No, se permiten Campos Vacíos", function () { }); 


    }else{
      alertify.alert("Usuario y contraseña Incorrecta", function () { });
    }

    

    console.log(error);
  }
};


const doReset = async () => {
  try {
    if(email.value==="" || email.value===undefined ){
      alertify.alert("El correo es requerido", function () { });
    
    }else{ 
       await firebase
        .auth().sendPasswordResetEmail(email.value);
        alertify.alert(`${email.value} revisa tu bandeja de correo recibidos`, function () { });
       
        setTimeout(() => {
          location.reload();
        }, 6000);
      }
  } catch (error) {
    console.log(error)
  }
}