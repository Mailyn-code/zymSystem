let apiUrl = "http://localhost:8082/api/sucursales";

const contenedor = document.querySelector("tbody");
let {codigoSucursal,descripcionSucursal} =
document.forms["formularioSucursal"];
let resultados = "";

const getSucursal= async() => {
  try {
    
  
  const response = await fetch(apiUrl);
  const sucursales = await response.json();
  const { data, success } = sucursales;

  data.forEach((sucursal) => {
    const {
      COD_SUCURSAL,
      NOM_SUCURSAL,
    
    } = sucursal;

    resultados += `
    <tr>
    <td class="dataItem">${JSON.stringify(sucursal)}</td>
   
   <td>${ COD_SUCURSAL}</td>
   <td>${ NOM_SUCURSAL}</td>
   <td>
   <button type="button" class="btnBorrar btn btn-danger">
       Eliminar
       </i>
     </button>
     <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#modalCategoria">
    Actualizar
       </i>
     </button>
     </td>
   </tr>
                  `;
  }); 
  contenedor.innerHTML = resultados;


} catch (error) {
    
}
};

const postSucursal = async () => {
  try {

    if( codigoSucursal.value===""||descripcionSucursal.value===""){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      nomSucursal: codigoSucursal.value,
      dirSucursal: descripcionSucursal.value
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        nomSucursal: codigoSucursal.value,
        dirSucursal: descripcionSucursal.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }

};



getSucursal();
  