let apiUrl = "http://localhost:8082/api/password";

const contenedor = document.querySelector("tbody");
let { codigoUsuario,contraseñaNueva,token,codigo,email } =
document.forms["formularioRecuperarContraseña"];
let resultados = "";
 
const getRecuperarContraseña= async() => {
  try {
    
  
  const response = await fetch(apiUrl);
  const RecuperarContraseñas = await response.json();
  const { data, success } = RecuperarContraseñas;

  data.forEach((RecuperarContraseña) => {
    const {
      COD_RESET_PASSWORD,
      DES_PASSWORD_NUEVA,
      TOKEN,
      CODIGO,
      EMAIL,
      
    
    } =RecuperarContraseña;

    resultados += `
    <tr>
    <td class="dataItem">${JSON.stringify(RecuperarContraseñas)}</td>
     <td>${COD_RESET_PASSWORD}</td>
     <td>${DES_PASSWORD_NUEVA}</td>
     <td>${TOKEN}</td>
    <td>${CODIGO}</td>
   <td>${EMAIL}</td>
   <td>
   <button type="button" class="btnBorrar btn btn-danger">
       Eliminar
       </i>
     </button>
     <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#modalCategoria">
    Actualizar
       </i>
     </button>
     </td>
   </tr>
                  `;
  }); 
  contenedor.innerHTML = resultados;


} catch (error) {
    
}
};
const postResetPassword= async () => {
  try {
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        codUsuario:codigoUsuario.value,
        desPassword:contraseñaNueva.value,
        token:token.value,
        codigo:codigo.value,
        email:email.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    location.reload();
    console.log(data);
  } catch (error) {
    console.log(error);
  }
};



getRecuperarContraseña();
