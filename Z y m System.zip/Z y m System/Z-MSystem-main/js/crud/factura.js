let apiUrl = "http://localhost:8082/api/facturas";

let apiUrl1="http://localhost:8082/api/infoProducto";

const contenedor = document.querySelector("tbody");
let idRegistro;
let {codigoProducto,rtnFactura,codigoPersona,codigoBarraProducto,loteProducto,cantidadProducto,precioProducto,totalVenta,formaPago,efectivoRecibido,montoTarjeta,cambioEfectivo,codigoUsuario,codigoSucursal} =
document.forms["formularioFactura"];

let idRegistross=1000;

const btnGuardar = document.querySelector(".contentBtnGuardar");

const inputCambio = document.querySelector('#efectivoRecibido');

inputCambio.addEventListener('input', updateCambio);

let cantidad=0;
let cambio=0;
let montoTotal=0;



function updateCambio(e) {
  cantidad=e.target.value;
  montoTotal=cantidad-totalVenta.value;
  cambioEfectivo.value=montoTotal;
}




let resultados = "";

const getFacturas = async () => {
  try {
    const role = window.localStorage.getItem("role");
    const codigoUsuario = window.localStorage.getItem("codigoUsuario");

    const url =
      role === "Administrador"
        ? apiUrl
        : `${apiUrl}?idUsuario=${codigoUsuario}`;


    const response = await fetch(url);
    const facturas = await response.json();
    const { data, success } = facturas;

    data.forEach((factura) => {
      const {
        COD_FACTURA,
        COD_BARRA_PRODUCTO,
        COD_PRODUCTO,
        CAN_PROD_FACTURA,
        PRE_PROD_FACTURA,
        TOT_FACTURA,
        RTN_FACTURA,
        PRIMER_NOM_PERSONA,
        DES_FORMA_PAGO,
        MONTO_TARJETA,
        EFECTIVO_RECIBIDO_FACTURA,
        CAMBIO_EFECTIVO_FACTURA,
        FEC_FACTURA,
        NOM_SUCURSAL,
        COD_SUCURSAL,
        COD_USUARIO,
        LOTE_PRODUCTO,
      
      
      } = factura;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(factura)}</td>
      <td>${COD_FACTURA}</td>
       <td>${COD_BARRA_PRODUCTO}</td>
       <td>${COD_PRODUCTO}</td>
       <td>${CAN_PROD_FACTURA}</td>
       <td>${PRE_PROD_FACTURA}</td>
       <td>${TOT_FACTURA}</td>
       <td>${RTN_FACTURA}</td>
       <td>${PRIMER_NOM_PERSONA}</td>
       <td>${DES_FORMA_PAGO}</td>
       <td>${MONTO_TARJETA}</td>
       <td>${EFECTIVO_RECIBIDO_FACTURA}</td>
       <td>${CAMBIO_EFECTIVO_FACTURA}</td>
       <td>${FEC_FACTURA}</td>
       <td>${NOM_SUCURSAL}</td>
      
       <td>
      
         <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
        Actualizar
           </i>
         </button>
         </td>
       </tr>
       `;

                    
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};





const postFactura= async () => {
  try {

    if(codigoProducto.value==="" || codigoPersona.value===""|| codigoBarraProducto.value===""|| 
    loteProducto.value===""|| cantidadProducto.value==="" || precioProducto.value==="" ||
    totalVenta.value===""|| formaPago.value==="" || efectivoRecibido.value==="" || 
    cambioEfectivo.value===""||codigoUsuario.value===""||codigoSucursal.value==="" ){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      codBarraProd:codigoBarraProducto.value,
      loteProd:loteProducto.value,
      canProdFactura:cantidadProducto.value,
      preProdFactura:precioProducto.value,
      totFactura:totalVenta.value,
      efecReciFactura:efectivoRecibido.value,
      cambioEfecFactura:cambioEfectivo.value,
      rtnFactura:rtnFactura.value,
      codProducto:codigoProducto.value,
      codFormaPago:formaPago.value,
      codUsuario:codigoUsuario.value,
      codSucursal:codigoSucursal.value,
      codPersona:codigoPersona.value,
      monTarjeta:montoTarjeta.value 
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        codBarraProd:codigoBarraProducto.value,
        loteProd:loteProducto.value,
        canProdFactura:cantidadProducto.value,
        preProdFactura:precioProducto.value,
        totFactura:totalVenta.value,
        efecReciFactura:efectivoRecibido.value,
        cambioEfecFactura:cambioEfectivo.value,
        rtnFactura:rtnFactura.value,
        codProducto:codigoProducto.value,
        codFormaPago:formaPago.value,
        codUsuario:codigoUsuario.value,
        codSucursal:codigoSucursal.value,
        codPersona:codigoPersona.value,
        monTarjeta:montoTarjeta.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 1000);
      }

  } catch (error) {
    console.log(error);
  }

};

//PUT
const putFactura= async () => {
  try {
  
    let body;

      body = {
        codFactura:idRegistro,
        codBarraProd:codigoBarraProducto.value,
        loteProd:loteProducto.value,
        canProdFactura:cantidadProducto.value,
        preProdFactura:precioProducto.value,
        totFactura:totalVenta.value,
        efecReciFactura:efectivoRecibido.value,
        cambioEfecFactura:cambioEfectivo.value,
        rtnFactura:rtnFactura.value,
        codProducto:codigoProducto.value,
        codFormaPago:formaPago.value,
        codPersona:codigoPersona.value,
        monTarjeta:montoTarjeta.value
        

      };
    
     

    console.log(body)
    const requestOptions = {
      method: "PUT",
      body: JSON.stringify(body),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
   location.reload();
  } catch (error) {
    console.log(error.message);
  }
};



const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postFactura()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro

on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {


    COD_FACTURA,
    COD_BARRA_PRODUCTO,
    LOTE_PRODUCTO,
    CAN_PROD_FACTURA,
    PRE_PROD_FACTURA,
    TOT_FACTURA,
    EFECTIVO_RECIBIDO_FACTURA,
    CAMBIO_EFECTIVO_FACTURA,
    RTN_FACTURA,
    COD_PRODUCTO,
    COD_FORMA_PAGO,
    COD_USUARIO,
    COD_SUCURSAL,
    COD_PERSONA,
    MONTO_TARJETA
  } = JSON.parse(id);

        codigoBarraProducto.value=COD_BARRA_PRODUCTO;
        loteProducto.value=LOTE_PRODUCTO;
        cantidadProducto.value=CAN_PROD_FACTURA;
        precioProducto.value=PRE_PROD_FACTURA;
        totalVenta.value=TOT_FACTURA;
        efectivoRecibido.value=EFECTIVO_RECIBIDO_FACTURA;
        cambioEfectivo.value=CAMBIO_EFECTIVO_FACTURA;
        rtnFactura.value=RTN_FACTURA;
        codigoProducto.value=COD_PRODUCTO;
        formaPago.value=COD_FORMA_PAGO;
        codigoUsuario.value=COD_USUARIO;
        codigoSucursal.value=COD_SUCURSAL;
        codigoPersona.value=COD_PERSONA;
        montoTarjeta.value=MONTO_TARJETA;
        idRegistro=COD_FACTURA;

  btnGuardar.innerHTML = `  <button onclick="putFactura()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});


const getProductosSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/productos");
  const productos = await response.json();
  const { data, success } = productos;
  console.log({data})
  const contenedorSelect = document.querySelector("#codigoProducto");
  let resultadosSelect = `<option value="">Por favor elija una opción</option>`;
  data.forEach((producto) => {
    const { COD_PRODUCTO,NOM_PRODUCTO} = producto;

    resultadosSelect += `
 
   <option value="${COD_PRODUCTO}">${NOM_PRODUCTO} </option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};
const getPersonasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/personas");
  const personas = await response.json();
  const { data, success } = personas;
  const contenedorSelect = document.querySelector("#codigoPersona");
  let resultadosSelect = `<option value="">Por favor elija una opción</option>`;
  data.forEach((persona) => {
    const { COD_PERSONA,PRIMER_NOM_PERSONA,	PRIMER_APELLIDO_PERSONA} = persona;

    resultadosSelect += `
 
   <option value="${COD_PERSONA}">${PRIMER_NOM_PERSONA}  ${PRIMER_APELLIDO_PERSONA} </option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getMarcasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/sucursales");
  const sucursales = await response.json();
  const { data, success } = sucursales;
  const contenedorSelect = document.querySelector("#codigoSucursal");
  let resultadosSelect = `<option value="">Por favor elija una opción</option>`;
  data.forEach((sucursal) => {
    const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;

    resultadosSelect += `
 
   <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};


const getUsuarioSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/usuarios");
  const categorias = await response.json();
  const { data, success } = categorias;
  const contenedorSelect = document.querySelector("#codigoUsuario");
  let resultadosSelect = `<option value="">Por favor elija una opción</option>`;
  data.forEach((usuario) => {
    const { COD_USUARIO, USUARIO_USR } = usuario;

    resultadosSelect += `
 
   <option value="${COD_USUARIO}">${USUARIO_USR}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getLoteSelect= async() => {
  try {

    let {codigoProducto} =document.forms["formularioFactura"];
const codP=codigoProducto.value;

const url =
    codP === codigoProducto.value
        ? `${apiUrl1}?codProducto=${codP}`
        : `${apiUrl1}?codProducto=${codP}`;

    //const url = `${apiUrl1}?codProducto=${codP}`;

    const response = await fetch(url);
    const infos = await response.json();
    const { data, success } = infos;
console.log({data})
  const contenedorSelect = document.querySelector("#loteProducto");
  let resultadosSelect = `<option value="">Por favor elija una opción</option>`;
  data.forEach((lote) => {
    const {   
CODIGO_LOTE,COD_DE_BARRA_PRODUCTO,COD_PRODUCTO,DES_PRODUCTO,NOM_PRODUCTO,PRECIO_VENTA

            } = lote;

    resultadosSelect += `
 
   <option value="${CODIGO_LOTE}">${CODIGO_LOTE}</option>
  
  
                `;
  codigoBarraProducto.value=COD_DE_BARRA_PRODUCTO;
  precioProducto.value=PRECIO_VENTA;


  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
} catch (error) {
    
}
};
const inputCantidad = document.querySelector('#cantidadProducto');


inputCantidad.addEventListener('input', updateCantidad);




function updateCantidad(e) {
  cantidad=e.target.value;
  montoTotal=cantidad*precioProducto.value;
  totalVenta.value=montoTotal;
}






getFacturas ();
getProductosSelect();
getPersonasSelect();
getMarcasSelect();
getUsuarioSelect();


  

  