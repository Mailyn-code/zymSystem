var tb=document.getElementById("info");
var fil=0,col=0;
var op=false;


let apiUrl = "http://localhost:8082/api/compras";
let apiUrl1="http://localhost:8082/api/infoProducto";
const contenedor = document.querySelector("tbody");
let { codigoBarraProducto,codigoUsuario,codigoPersona, codigoProducto,descripcionCompra,cantidadCompra,costoUnitario,fechaElaboracionProducto,fechaCaducidadProducto,loteCompra,loteTotalCompra,montoTotalCompra,codigoSucursal } =
document.forms["formularioCompras"];
const btnGuardar = document.querySelector(".contentBtnGuardar");
let resultados = "";
const inputCantidad = document.querySelector('#cantidadCompra');
const inputCostoUnitario = document.querySelector('#costoUnitario');

inputCantidad.addEventListener('input', updateCantidad);
inputCostoUnitario.addEventListener('input', updateCostoUnitario);

let cantidad=0;
let costoUnidad=0;
let montoTotal=0;



function updateCantidad(e) {
  cantidad=e.target.value;
  montoTotal=cantidad*costoUnidad;
  montoTotalCompra.value=montoTotal;
  loteTotalCompra.value=cantidad;

}


function updateCostoUnitario(e) {
  costoUnidad=e.target.value;
  montoTotal=cantidad*costoUnidad;
  montoTotalCompra.value=montoTotal;

}

function agregar(){
  
if (verificar(codigoBarraProducto)){
var x = tb.rows[fil].cells;
var x2 = parseInt(x[2].innerHTML)+parseInt(cantidadCompra)
x[2].innerHTML=x2;
x[3].innerHTML=parseInt(costoUnitario) *x2;
resultados();
op=false;
}else{
var n = tb.rows.length;
var row= tb.insertRow(n);
var cell1= row.insertCell(0);
var cell2= row.insertCell(1);
var cell3= row.insertCell(2);
var cell4= row.insertCell(3);
var cell5= row.insertCell(4);
var cell6= row.insertCell(5);
var cell7= row.insertCell(6);
var cell8= row.insertCell(7);
var cell9= row.insertCell(8);
var cell10= row.insertCell(9);
cell1.innerHTML=1;
cell2.innerHTML= codigoBarraProducto.value;
cell3.innerHTML=codigoProducto.value;
cell4.innerHTML=cantidadCompra.value;
cell5.innerHTML=costoUnitario.value;
cell6.innerHTML=montoTotalCompra.value;
cell7.innerHTML=loteCompra.value;
cell8.innerHTML=fechaElaboracionProducto.value;
cell9.innerHTML=fechaCaducidadProducto.value;
cell10.innerHTML="Eliminar";
resultado();


}
}
function verificar(p){
for (var i=0; i<tb.rows.length; i++)
{
  if(tb.rows[i].cells[0].innerHTML==p){
op = true;
fil=i;col=0;

  }
}
return op;


}
function resultado(){
  var suma=0;
  for (var i=1; i<tb.rows.length; i++){
    suma=suma + parseInt(tb.rows[i].cells[5].innerHTML);
}
document.getElementById("Subtotal").value=suma;
document.getElementById("ISV").value=0;
document.getElementById("total").value=suma + 0;

var app = angular.module("app", []); 
              app.controller("myCtrl", function($scope) {
                   this.$onInit = function () {
                    //Se abre el modal
                   var element = angular.element('#myModal');
                   element.modal('show');
                   //Se cierra despues de 5 segundos
                   setTimeout(function(){
                      element.modal('hide');
                   }, 5000);
                  }
      });

    







}
function limpiar(){
codigoBarraProducto.value="";
      codigoUsuario.value="";
      codigoPersona.value="";
      codigoProducto.value="";
      descripcionCompra.value="";
      cantidadCompra.value="";
      costoUnitario.value="";
      loteCompra.value="";
      loteTotalCompra.value="";
      montoTotalCompra.value="";
      codigoSucursal.value="";
    }
/*
const getCompras= async() => {
  try {
    const role = window.localStorage.getItem("role");
    const codigoUsuario = window.localStorage.getItem("codigoUsuario");

    const url =
      role === "Administrador"
        ? apiUrl
        : `${apiUrl}?idUsuario=${codigoUsuario}`;

  console.log("codigoUsuario")
  const response = await fetch(url);
  const compras = await response.json();
  const { data, success } = compras;

  data.forEach((compra) => {
    const {
      COD_COMPRA,
      COD_BARRA_PRODUCTO,
      COD_PRODUCTO,
      DES_COMPRA,
      CAN_COMPRA,
      COSTO_UNITARIO,
      TOT_COMPRA,
      LOTE_TOTAL_COMPRA,
      LOTE_COMPRA,
      FEC_ELABORACION_PRODUCTO,
      FEC_CADUCIDAD,
      FEC_COMPRA,
      PRIMER_NOM_PERSONA,

      NOM_SUCURSAL,
    } = compra;

    resultados += `
    <tr>
    <td class="dataItem">${JSON.stringify(compra)}</td>
    <td>${ COD_COMPRA}</td>
     <td>${COD_BARRA_PRODUCTO}</td>
     <td>${COD_PRODUCTO}</td>
     <td>${DES_COMPRA}</td>
    <td>${CAN_COMPRA}</td>
   <td>${COSTO_UNITARIO}</td>
   <td>${TOT_COMPRA}</td>
   <td>${LOTE_TOTAL_COMPRA}</td>
   <td>${ FEC_ELABORACION_PRODUCTO}</td>
   <td>${FEC_CADUCIDAD}</td>
   <td>${ FEC_COMPRA}</td>
   <td>${PRIMER_NOM_PERSONA}</td>
   <td>${ NOM_SUCURSAL}</td>
   <td>
   <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
   Actualizar
      </i>
    </button>
     </td>
   </tr>
   `;
  });

  contenedor.innerHTML = resultados;
} catch (error) {
  console.log(error);
}
};





const postCompras = async () => {
  try {

    if(codigoBarraProducto.value===""||codigoUsuario.value===""||codigoPersona.value===""||
     codigoProducto.value===""||descripcionCompra.value===""||cantidadCompra.value===""||
     costoUnitario.value===""||fechaElaboracionProducto.value===""||fechaCaducidadProducto.value===""||
     loteCompra.value===""||loteTotalCompra.value===""||montoTotalCompra.value===""||codigoSucursal.value===""){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      codBarraProducto:codigoBarraProducto.value,
        desCompra:descripcionCompra.value,
        canCompra:cantidadCompra.value,
        fecElaboracion:fechaElaboracionProducto.value,
        fecCaducidad:fechaCaducidadProducto.value,
        loteCompra:loteCompra.value,
        loteTotal:loteTotalCompra.value,
        totalCompra:montoTotalCompra.value,
        codUsuario:codigoUsuario.value,
        codSucursal:codigoSucursal.value ,
        codProducto:codigoProducto.value,
        codPersona:codigoPersona.value,
        costoUnitario:costoUnitario.value
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        codBarraProducto:codigoBarraProducto.value,
        desCompra:descripcionCompra.value,
        canCompra:cantidadCompra.value,
        fecElaboracion:fechaElaboracionProducto.value,
        fecCaducidad:fechaCaducidadProducto.value,
        loteCompra:loteCompra.value,
        loteTotal:loteTotalCompra.value,
        totalCompra:montoTotalCompra.value,
        codUsuario:codigoUsuario.value,
        codSucursal:codigoSucursal.value ,
        codProducto:codigoProducto.value,
        codPersona:codigoPersona.value,
        costoUnitario:costoUnitario.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }

};

*/
const getInfoSelect= async() => {
  try {

    let {codigoProducto} =document.forms["formularioCompras"];
const codP=codigoProducto.value;

const url =
    codP === codigoProducto.value
        ? `${apiUrl1}?codProducto=${codP}`
        : `${apiUrl1}?codProducto=${codP}`;

    //const url = `${apiUrl1}?codProducto=${codP}`;

    const response = await fetch(url);
    const infos = await response.json();
    const { data, success } = infos;
console.log({data})
 
  data.forEach((lote) => {
    const {   
CODIGO_LOTE,COD_DE_BARRA_PRODUCTO,COD_PRODUCTO,DES_PRODUCTO,NOM_PRODUCTO,PRECIO_VENTA

            } = lote;

  codigoBarraProducto.value=COD_DE_BARRA_PRODUCTO;
  descripcionCompra.value=DES_PRODUCTO;


  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
} catch (error) {
    
}
}; 

const getPersonasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/personas");
  const personas = await response.json();
  const { data, success } = personas;
  const contenedorSelect = document.querySelector("#codigoPersona");
  let resultadosSelect = `<option value="">Por favor elija una opción</option>`;
  data.forEach((persona) => {
    const { COD_PERSONA,PRIMER_NOM_PERSONA,	PRIMER_APELLIDO_PERSONA} = persona;

    resultadosSelect += `
 
   <option value="${COD_PERSONA}">${PRIMER_NOM_PERSONA}  ${PRIMER_APELLIDO_PERSONA} </option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getProductosSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/productos");
  const productos = await response.json();
  const { data, success } = productos;
  const contenedorSelect = document.querySelector("#codigoProducto");
  let resultadosSelect = `<option value="">Por favor elija una opción</option>`;
  data.forEach((producto) => {
    const { COD_PRODUCTO,NOM_PRODUCTO} = producto;

    resultadosSelect += `
 
   <option value="${COD_PRODUCTO}">${NOM_PRODUCTO} </option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};
const getUsuarioSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/usuarios");
  const categorias = await response.json();
  const { data, success } = categorias;
  const contenedorSelect = document.querySelector("#codigoUsuario");
  let resultadosSelect = `<option value="">Por favor elija una opción</option>`;
  data.forEach((usuario) => {
    const { COD_USUARIO, USUARIO_USR } = usuario;

    resultadosSelect += `
 
   <option value="${COD_USUARIO}">${USUARIO_USR}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getMarcasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/sucursales");
  const sucursales = await response.json();
  const { data, success } = sucursales;
  const contenedorSelect = document.querySelector("#codigoSucursal");
  let resultadosSelect = `<option value="">Por favor elija una opción</option>`;
  data.forEach((sucursal) => {
    const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;

    resultadosSelect += `
 
   <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

/*
const putCompras= async (id = null, estado = null) => {
  try {

    console.log(idRegistro)
    let body;
    if (id) {
      const {
        COD_COMPRA,
        COD_BARRA_PRODUCTO,
        COD_PRODUCTO,
        DES_COMPRA,
        CAN_COMPRA,
        COSTO_UNITARIO,
        TOT_COMPRA,
        LOTE_TOTAL_COMPRA,
        FEC_ELABORACION_PRODUCTO,
        FEC_CADUCIDAD,
        FEC_COMPRA,
        PRIMER_NOM_PERSONA,
        NOM_SUCURSAL,

      } = JSON.parse(id);
    
      body = {
        codCompra:idRegistro,
        codBarraProducto:codigoBarraProducto.value,
        desCompra:descripcionCompra.value,
        canCompra:cantidadCompra.value,
        fecElaboracion:fechaElaboracionProducto.value,
        fecCaducidad:fechaCaducidadProducto.value,
        loteCompra:loteCompra.value,
        loteTotal:loteTotalCompra.value,
        totalCompra:montoTotalCompra.value,
        codUsuario:codigoUsuario.value,
        codSucursal:codigoSucursal.value ,
        codProducto:codigoProducto.value,
        codPersona:codigoPersona.value,
        costoUnitario:costoUnitario.value
    

      
      };
    } else {
      body = {
        codCompra:idRegistro,
        codBarraProducto:codigoBarraProducto.value,
        desCompra:descripcionCompra.value,
        canCompra:cantidadCompra.value,
        fecElaboracion:fechaElaboracionProducto.value,
        fecCaducidad:fechaCaducidadProducto.value,
        loteCompra:loteCompra.value,
        loteTotal:loteTotalCompra.value,
        totalCompra:montoTotalCompra.value,
        codUsuario:codigoUsuario.value,
        codSucursal:codigoSucursal.value ,
        codProducto:codigoProducto.value,
        codPersona:codigoPersona.value,
        costoUnitario:costoUnitario.value

      };
    }

    console.log(body)
    const requestOptions = {
      method: "PUT",
      body: JSON.stringify(body),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
 location.reload();
  } catch (error) {
    console.log(error.message);
  }
};



const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postCompras()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro
on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {
    COD_COMPRA,
    COD_BARRA_PRODUCTO,
    COD_PRODUCTO,
    DES_COMPRA,
    CAN_COMPRA,
    COSTO_UNITARIO,
    TOT_COMPRA,
    LOTE_TOTAL_COMPRA,
    LOTE_COMPRA,
    FEC_ELABORACION_PRODUCTO,
    FEC_CADUCIDAD,
    FEC_COMPRA,
    PRIMER_NOM_PERSONA,
    NOM_SUCURSAL,
    COD_SUCURSAL,
     COD_USUARIO,
     COD_PERSONA
  } = JSON.parse(id);

  codigoBarraProducto.value=COD_BARRA_PRODUCTO;
  codigoUsuario.value=COD_USUARIO;
  codigoPersona.value=COD_PERSONA;
  codigoProducto.value=COD_PRODUCTO;
  descripcionCompra.value=DES_COMPRA;
  cantidadCompra.value=CAN_COMPRA;
  costoUnitario.value=COSTO_UNITARIO;
  loteCompra.value=LOTE_COMPRA;
  loteTotalCompra.value=LOTE_TOTAL_COMPRA;
  montoTotalCompra.value=TOT_COMPRA;
  codigoSucursal.value=COD_SUCURSAL;


  btnGuardar.innerHTML = `  <button onclick="putCompras()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});

*/
//getCompras();
getPersonasSelect()

getProductosSelect()
getUsuarioSelect()
getMarcasSelect();