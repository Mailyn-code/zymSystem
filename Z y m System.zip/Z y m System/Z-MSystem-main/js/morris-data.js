let apiUrl = "http://localhost:8082/api/estadisticas";

const clientes = document.querySelector(".clientes");
const venta = document.querySelector(".venta");
const compras = document.querySelector(".compras");
const productos = document.querySelector(".productos");

const getEstadisticas = async () => {
  const response = await fetch(apiUrl);
  const ventas = await response.json();
  const { data, success } = ventas;
  const { coutClientes, coutVentas, coutCompras, coutProductos } = data;

  clientes.innerHTML = coutClientes;
  venta.innerHTML = coutVentas;
  compras.innerHTML = coutCompras;
  productos.innerHTML = coutProductos;
  console.log(data);
};

$(function () {
  Morris.Area({
    element: "morris-area-chart",
    data: [
      {
        period: "2012-02-24",
        compra: 2666,
        venta: null,
      },
      {
        period: "2012-02-25",
        compra: 2778,
        venta: 2294,
      },
      {
        period: "2012-02-26",
        compra: 4912,
        venta: 26000,
      },
      {
        period: "2012-02-27",
        compra: 3767,
        venta: 3597,
      },
      {
        period: "2012-02-28",
        compra: 4912,
        venta: 1969,
      },
    ],
    xkey: "period",
    ykeys: ["compra", "venta"],
    labels: ["Compra", "Venta"],
    pointSize: 2,
    hideHover: "auto",
    resize: true,
  });

  Morris.Donut({
    element: "morris-donut-chart",
    data: [
      {
        label: "Ventas",
        value: 30,
      },
    ],
    resize: true,
  });
});

getEstadisticas();
