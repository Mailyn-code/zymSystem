const {Router}=require('express');
const {getInfoProducto}=require('../controllers/infoProducto');

const router= Router();


router.get("/",getInfoProducto);//obtener
module.exports=router;