
const {Router}=require('express');
const {getPresentacion, postPresentacion, putPresentacion}=require('../controllers/presentacion');

const router= Router();


router.get("/",getPresentacion);//obtener
router.post("/",postPresentacion);
router.put("/",putPresentacion);
module.exports=router;