
const {Router}=require('express');
const {getProductosAgotados}=require('../controllers/productosAgotados');

const router= Router();


router.get("/",getProductosAgotados);//obtener

module.exports=router;
