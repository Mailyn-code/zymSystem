const {Router}=require('express');
const {getEmail,postEmail,putEmail,deleteEmail}=require('../controllers/email');

const router= Router();


router.get("/",getEmail);//obtener
router.post("/",postEmail);
router.put("/",putEmail);
router.delete("/",deleteEmail);
module.exports=router;