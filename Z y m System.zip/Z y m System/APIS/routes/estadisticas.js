const { Router } = require("express");
const { getEstadisticas } = require("../controllers/estadisticas");

const router = Router();

router.get("/", getEstadisticas); //obtener

module.exports = router;
