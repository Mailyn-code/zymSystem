const {Router}=require('express');
const {getFormaPago}=require('../controllers/formaPago');

const router= Router();


router.get("/",getFormaPago);//obtener
module.exports=router;