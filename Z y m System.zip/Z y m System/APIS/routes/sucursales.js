const {Router}=require('express');
const {getSucursal,postSucursal,putSucursal}=require('../controllers/sucursales');

const router= Router();


router.get("/",getSucursal);//obtener
router.post("/",postSucursal);
router.put("/",putSucursal);
module.exports=router;