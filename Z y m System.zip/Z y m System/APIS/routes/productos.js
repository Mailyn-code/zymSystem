
const {Router}=require('express');
const {getProductos,postProductos,putProductos,deleteProductos}=require('../controllers/productos');

const router= Router();


router.get("/",getProductos);//obtener
router.post("/",postProductos);
router.put("/",putProductos);
router.delete("/",deleteProductos);
module.exports=router;

