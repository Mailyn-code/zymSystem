
const {Router}=require('express');
const {getResetPassword, postResetPassword}=require('../controllers/password');

const router= Router();


router.get("/",getResetPassword);//obtener
router.post("/",postResetPassword);
module.exports=router;