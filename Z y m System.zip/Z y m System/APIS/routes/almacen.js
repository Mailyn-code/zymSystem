const {Router}=require('express');
const {getAlmacen}=require('../controllers/almacen');

const router= Router();


router.get("/",getAlmacen);//obtener
module.exports=router;