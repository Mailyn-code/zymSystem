const {Router}=require('express');
const {getFactura,postFactura,putFactura}=require('../controllers/facturas');

const router= Router();


router.get("/",getFactura);//obtener
router.post("/",postFactura);
router.put("/",putFactura);
module.exports=router;