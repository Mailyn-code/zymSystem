
const {Router}=require('express');
const {getRoles,postRoles,putRoles,deleteRoles}=require('../controllers/roles');

const router= Router();


router.get("/",getRoles);//obtener
router.post("/",postRoles);
router.put("/",putRoles);
router.delete("/",deleteRoles);
module.exports=router;

