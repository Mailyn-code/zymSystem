const { request, response } = require("express");
const {mysqlGetRoles,mysqlPostRoles}=require("../models/roles");

const getRoles=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetRoles()
   if(success){
    res.json({
        mensaje:"Roles obtenido con exito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener los roles",
        success
        
       })
       
   }

} ;

const postRoles=async(req=request ,res=response)=>{
   
    const {desRol,codSucursal}=req.body;

    await mysqlPostRoles(desRol,codSucursal)
    res.json({
        mensaje:"Exito Post",
    })

} ;

const putRoles=(req=request ,res=response)=>{
    res.json({
        mensaje:"Exito Put",
    })

} ;

const deleteRoles=(req=request ,res=response)=>{
    res.json({
        mensaje:"Exito Delete",
    })

} ;

module.exports={
    getRoles,
    postRoles,
    putRoles,
    deleteRoles,

}