const { request, response } = require("express");
const {mysqlGetVentas}=require("../models/ventas");


const getVentas=async(req=request ,res=response)=>{
    
    const { idUsuario = null } = req.query;
    const {data,success}=await mysqlGetVentas(idUsuario)
    if(success){
     res.json({
         mensaje:"Información de Ventas de Productos obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de Ventas de Productos",
         success
         
        })
        
    }
 
} ;

module.exports= {
    getVentas
    }

