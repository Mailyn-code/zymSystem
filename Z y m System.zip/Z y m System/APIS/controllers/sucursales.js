const { request, response } = require("express");
const {mysqlGetSucursal,mysqlPostSucursal,mysqlPutSucursal}=require("../models/sucusales");


const getSucursal=async(req=request ,res=response)=>{
    
    const {data,success}=await mysqlGetSucursal()
    if(success){
     res.json({
         mensaje:"Informacion de Sucursales obtenida con exito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la informacion de las Sucursales",
         success
         
        })
        
    }
 
} ;


const postSucursal=async(req=request ,res=response)=>{
   
    const {nomSucursal,dirSucursal}=req.body;

    await mysqlPostSucursal(nomSucursal,dirSucursal)
    res.json({
        mensaje:"Exito Post",
    })

} ;


const putSucursal=async(req=request ,res=response)=>{
   
    const {codSucursal,nomSucursal,dirSucursal}=req.body;

    await mysqlPutSucursal(codSucursal,nomSucursal,dirSucursal)
    res.json({
        mensaje:"Exito Put",
    })

} ;

module.exports= {
    getSucursal,
    postSucursal,
    putSucursal,
    }


