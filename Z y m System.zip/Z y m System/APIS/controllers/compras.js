const { request, response } = require("express");
const {mysqlGetCompras,mysqlPostCompras,mysqlPutCompras}=require("../models/compras");

const getCompras=async(req=request ,res=response)=>{
    const { idUsuario = null } = req.query;
    console.log("idUsuario")
    const { data, success } = await mysqlGetCompras(idUsuario);
   if(success){
    res.json({
        mensaje:"Compras obtenidas con exito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener los Compras",
        success
        
       })
       
   }

} ;

const postCompras=async(req=request ,res=response)=>{
   
    const {codBarraProducto,desCompra,canCompra,fecElaboracion,fecCaducidad,loteCompra,loteTotal,totalCompra,codUsuario,codSucursal,codProducto,codPersona,costoUnitario}=req.body;

    await mysqlPostCompras(codBarraProducto,desCompra,canCompra,fecElaboracion,fecCaducidad,loteCompra,loteTotal,totalCompra,codUsuario,codSucursal,codProducto,codPersona,costoUnitario)
    res.json({
        mensaje:"Exito Post",
    })

} ;
const putCompras=async(req=request ,res=response)=>{
   
    const {codCompra,codBarraProducto,desCompra,canCompra,fecElaboracion,fecCaducidad,loteCompra,loteTotal,totalCompra,codUsuario,codSucursal,codProducto,codPersona,costoUnitario}=req.body;

    await mysqlPutCompras(codCompra,codBarraProducto,desCompra,canCompra,fecElaboracion,fecCaducidad,loteCompra,loteTotal,totalCompra,codUsuario,codSucursal,codProducto,codPersona,costoUnitario)
    res.json({
        mensaje:"Exito Put",
    })

} ;





module.exports={
    getCompras,
    postCompras,
    putCompras,

}