const { request, response } = require("express");
const {mysqlGetCategorias,mysqlPostCategorias,mysqlPutCategorias}=require("../models/categorias");

const getCategorias=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetCategorias()
   if(success){
    res.json({
        mensaje:"Categorias obtenidos con exito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener los Categorias",
        success
        
       })
       
   }

} ;

const postCategorias=async(req=request ,res=response)=>{
   
    const {desCategoria,numEstanteCategoria,indCategoria,codSucursal}=req.body;

    await mysqlPostCategorias(desCategoria,numEstanteCategoria,indCategoria,codSucursal)
    res.json({
        mensaje:"Exito Post",
    })

} ;

const putCategorias=async(req=request ,res=response)=>{
    const {codCategoria,desCategoria,numEstanteCategoria,indCategoria}=req.body;

await mysqlPutCategorias(codCategoria,desCategoria,numEstanteCategoria,indCategoria)

    res.json({
        mensaje:"Exito Put",
    })

} ;

module.exports={
    getCategorias,
    postCategorias,
    putCategorias,
}