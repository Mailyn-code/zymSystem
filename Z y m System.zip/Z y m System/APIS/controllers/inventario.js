const { request, response } = require("express");
const {mysqlGetInventario}=require("../models/inventario");


const getInventario=async(req=request ,res=response)=>{
    const { idUsuario = null } = req.query;
    const {data,success}=await mysqlGetInventario(idUsuario)
    if(success){
     res.json({
         mensaje:"Información de Inventario obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de Inventario",
         success
         
        })
        
    }
 
} ;

module.exports= {
    getInventario,
    }
     