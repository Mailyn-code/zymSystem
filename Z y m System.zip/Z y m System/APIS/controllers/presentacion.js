const { request, response } = require("express");
const {mysqlGetPresentacion,mysqlPostPresentacion,mysqlPutPresentacion}=require("../models/presentacion");

const getPresentacion=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetPresentacion()
   if(success){
    res.json({
        mensaje:"Presentaciones obtenidas con exito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener las Presentaciones",
        success
        
       })
       
   }

} ;

const postPresentacion=async(req=request ,res=response)=>{
   
    const {desPresentacion,codSucursal,unidadMedicion,canMedicion}=req.body;

    await mysqlPostPresentacion(desPresentacion,codSucursal,unidadMedicion,canMedicion)
    res.json({
        mensaje:"Exito Post",
    })

} ;

const putPresentacion=async(req=request ,res=response)=>{
    const {codPresentacion,desPresentacion,unidadMedicion,canMedicion}=req.body;

await mysqlPutPresentacion(codPresentacion,desPresentacion,unidadMedicion,canMedicion)

    res.json({
        mensaje:"Exito Put",
    })

} ;

module.exports={
    getPresentacion,
    postPresentacion,
    putPresentacion,
}