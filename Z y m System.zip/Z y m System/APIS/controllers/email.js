const { request, response } = require("express");
const {mysqlGetEmail,mysqlPostEmail,mysqlPutEmail,mysqlDeleteEmail}=require("../models/email");


const getEmail=async(req=request ,res=response)=>{
    
    const {data,success}=await mysqlGetEmail()
    if(success){
     res.json({
         mensaje:"Información de Email obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de Email",
         success
         
        })
        
    }
 
} ;


const postEmail=async(req=request ,res=response)=>{
   
    const {desEmail,codPersona}=req.body;

    await mysqlPostEmail(desEmail,codPersona)
    res.json({
        mensaje:"Éxito Post",
    })

} ;

const putEmail=async(req=request ,res=response)=>{
   
    const {codEmail,codPersona,desEmail}=req.body;

    console.log(codEmail,codPersona,desEmail)
    await mysqlPutEmail(codEmail,codPersona,desEmail)
    res.json({
        mensaje:"Éxito Put",
    })

} ;

const deleteEmail=async(req=request ,res=response)=>{
   
    const {codEmail}=req.body;

    await mysqlDeleteEmail(codEmail)
    res.json({
        mensaje:"Éxito Put",
    })

} ;


module.exports= {
    getEmail,
    postEmail,
    putEmail,
    deleteEmail,
    }
     
    
    

