const { request, response } = require("express");
const {mysqlGetFactura,mysqlPostFactura,mysqlPutFactura}=require("../models/facturas");


const getFactura=async(req=request ,res=response)=>{
    const { idUsuario = null } = req.query;
    const {data,success}=await mysqlGetFactura(idUsuario)
    if(success){
     res.json({
         mensaje:"Información de Facturas obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de Facturas",
         success
         
        })
        
    }
 
} ;

const postFactura=async(req=request ,res=response)=>{
   
    const {codBarraProd,loteProd,canProdFactura,preProdFactura,totFactura,efecReciFactura,cambioEfecFactura,rtnFactura,codProducto,codFormaPago,codUsuario,codSucursal,codPersona,monTarjeta}=req.body;

    await mysqlPostFactura(codBarraProd,loteProd,canProdFactura,preProdFactura,totFactura,efecReciFactura,cambioEfecFactura,rtnFactura,codProducto,codFormaPago,codUsuario,codSucursal,codPersona,monTarjeta)
    res.json({
        mensaje:"Éxito Post",
    })

} ;

const putFactura=async(req=request ,res=response)=>{
   
    const {codFactura,codBarraProd,loteProd,canProdFactura,preProdFactura,totFactura,efecReciFactura,cambioEfecFactura,rtnFactura,codProducto,codFormaPago,codPersona,monTarjeta}=req.body;

    await mysqlPutFactura(codFactura,codBarraProd,loteProd,canProdFactura,preProdFactura,totFactura,efecReciFactura,cambioEfecFactura,rtnFactura,codProducto,codFormaPago,codPersona,monTarjeta)
    res.json({
        mensaje:"Éxito Put",
    })

} ;

module.exports= {
    getFactura,
    postFactura,
    putFactura,
    }