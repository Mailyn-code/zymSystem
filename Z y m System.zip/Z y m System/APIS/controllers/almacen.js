const { request, response } = require("express");
const {mysqlGetAlmacen}=require("../models/almacen");


const getAlmacen=async(req=request ,res=response)=>{
    const { idUsuario = null } = req.query;
    const {data,success}=await mysqlGetAlmacen(idUsuario)
    if(success){
     res.json({
         mensaje:"Información de Almacén de Productos obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de Almacén de Productos",
         success
         
        })
        
    }
 
} ;

module.exports= {
    getAlmacen,
    }