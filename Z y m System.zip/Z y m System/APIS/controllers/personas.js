const { request, response } = require("express");
const {mysqlGetPersonas,mysqlPostPersonas,mysqlPutPersonas}=require("../models/personas");

const getPersonas=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetPersonas()
   if(success){
    res.json({
        mensaje:"Personas obtenidas con exito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener las Personas",
        success
        
       })
       
   }

} ;

const postPersonas=async(req=request ,res=response)=>{
   
    const {imgPersonas,primerNombre,segundoNombre,primerApellido,segundoApellido,dni,tel,tipoTelefono,dir,email,genero,fechaNacimiento,tipoPersona,codSucursal}=req.body;

    await mysqlPostPersonas(imgPersonas,primerNombre,segundoNombre,primerApellido,segundoApellido,dni,tel,tipoTelefono,dir,email,genero,fechaNacimiento,tipoPersona,codSucursal)
    res.json({
        mensaje:"Exito Post",
    })

} ;
const putPersonas=async(req=request ,res=response)=>{
   
    const {codPersona,imgPersonas,primerNombre,segundoNombre,primerApellido,segundoApellido,dni,tel,dir,email,genero,fechaNacimiento,tipoPersona,tipoTelefono}=req.body;

    await mysqlPutPersonas(codPersona,imgPersonas,primerNombre,segundoNombre,primerApellido,segundoApellido,dni,tel,dir,email,genero,fechaNacimiento,tipoPersona,tipoTelefono)
    res.json({
        mensaje:"Exito Put",
    })

} ;




module.exports={
    getPersonas,
    postPersonas,
    putPersonas,
    

}