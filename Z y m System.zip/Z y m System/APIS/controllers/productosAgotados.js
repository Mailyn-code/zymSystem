const { request, response } = require("express");
const {mysqlGetProductosAgotados}=require("../models/productosAgotados");


const getProductosAgotados=async(req=request ,res=response)=>{
    
    const {data,success}=await mysqlGetProductosAgotados()

    
    if(success){
     res.json({
         mensaje:"Información  obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información",
         success
         
        })
        
    }
 
} ;
module.exports={
    getProductosAgotados,


}