const { request, response } = require("express");
const {mysqlGetTelefonos,mysqlPostTelefonos,mysqlPutTelefonos,mysqlDeleteTelefonos}=require("../models/Telefonos");


const getTelefonos=async(req=request ,res=response)=>{
    
    const {data,success}=await mysqlGetTelefonos()
    if(success){
     res.json({
         mensaje:"Información de los Telefonos obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de Telefonos",
         success
         
        })
        
    }
 
} ;



const postTelefonos=async(req=request ,res=response)=>{
   
    const {numTel,tipoTel,codPersona}=req.body;

    await mysqlPostTelefonos(numTel,tipoTel,codPersona)
    res.json({
        mensaje:"Exito Post",
    })

} ;


const putTelefonos=async(req=request ,res=response)=>{
   
    const {numTel,tipoTel,codPersona}=req.body;

    await mysqlPutTelefonos(numTel,tipoTel,codPersona)
    res.json({
        mensaje:"Exito Put",
    })

} ;
const deleteTelefonos=async(req=request ,res=response)=>{
   
    const {codTelefono}=req.body;

    await mysqlDeleteTelefonos(codTelefono)
    res.json({
        mensaje:"Exito Delete",
    })

} ;


module.exports= {
    getTelefonos,
    postTelefonos,
    putTelefonos,
    deleteTelefonos,
    }
