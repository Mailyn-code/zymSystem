const { request, response } = require("express");
const { mysqlEstadisticas } = require("../models/estadisticas");

const getEstadisticas = async (req = request, res = response) => {
  const { data, success } = await mysqlEstadisticas();

  res.json({
    mensaje: "Estadisticas",
    data,
    success,
  });
};

module.exports = {
  getEstadisticas,
};
