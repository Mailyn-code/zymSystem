const { request, response } = require("express");
const {mysqlGetCaja,mysqlPostCaja,mysqlPutCaja}=require("../models/caja");


const getCaja=async(req=request ,res=response)=>{
    
    const {data,success}=await mysqlGetCaja()
    if(success){
     res.json({
         mensaje:"Informacion de Caja obtenida con exito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la informacion de caja",
         success
         
        })
        
    }
 
} ;

const postCaja=async(req=request ,res=response)=>{
   
    const {saldInicialCaja,saldAnteriorCaja,saldoFinalCaja,saldoCaja,codUsr,codSucursal}=req.body;

    await mysqlPostCaja(saldInicialCaja,saldAnteriorCaja,saldoFinalCaja,saldoCaja,codUsr,codSucursal)
    res.json({
        mensaje:"Exito Post",
    })

} ;

const putCaja=async(req=request ,res=response)=>{
   
    const {codCaja,saldInicialCaja,saldAnteriorCaja,saldoFinalCaja,saldoCaja}=req.body;

    await mysqlPutCaja(codCaja,saldInicialCaja,saldAnteriorCaja,saldoFinalCaja,saldoCaja)
    res.json({
        mensaje:"Exito Put",
    })

} ;

module.exports= {
getCaja,
postCaja,
putCaja,
}
 

