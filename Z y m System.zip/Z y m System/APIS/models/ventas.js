//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")


//metodos
const mysqlGetVentas=async(idUsuario)=>{
    const query=idUsuario
    ? `SELECT mi_ci_ventas.COD_VENTA,mi_ci_ventas.TOT_VENTA,msuc_ci_sucursales.NOM_SUCURSAL,
    mi_ci_ventas.FEC_VENTA,mi_ci_facturas.COD_FACTURA
    FROM mi_ci_ventas
     INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_ventas.COD_SUCURSAL
     INNER JOIN mi_ci_facturas ON mi_ci_facturas.COD_FACTURA= mi_ci_ventas.COD_FACTURA WHERE mi_ci_ventas.COD_USUARIO=${idUsuario}`
    : `SELECT mi_ci_ventas.COD_VENTA,mi_ci_ventas.TOT_VENTA,msuc_ci_sucursales.NOM_SUCURSAL,
    mi_ci_ventas.FEC_VENTA,mi_ci_facturas.COD_FACTURA
    FROM mi_ci_ventas
     INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_ventas.COD_SUCURSAL
     INNER JOIN mi_ci_facturas ON mi_ci_facturas.COD_FACTURA= mi_ci_ventas.COD_FACTURA`;
    const data=await queryTemplate(query);
    return data;
}



module.exports={mysqlGetVentas}

