const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

//metodos
const mysqlGetProductosPorVencer=async()=>{
    const query=`SELECT mi_ci_almacen_productos.CODIGO_BARRA_PRODUCTO,mprod_ci_productos.NOM_PRODUCTO, msuc_ci_sucursales.NOM_SUCURSAL,mi_ci_almacen_productos.DESC_PRODUCTO, mi_ci_almacen_productos.CODIGO_LOTE,mi_ci_almacen_productos.EXISTENCIA_LOTE, mi_ci_almacen_productos.FECHA_CADUCIDAD FROM mi_ci_almacen_productos INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_almacen_productos.COD_SUCURSAL INNER JOIN mprod_ci_productos ON mprod_ci_productos.COD_PRODUCTO= mi_ci_almacen_productos.COD_PRODUCTO WHERE (DATEDIFF( FECHA_CADUCIDAD,now()))<60 and EXISTENCIA_LOTE>1` 
    
    const data=await queryTemplate(query);
    return data;
}


module.exports={mysqlGetProductosPorVencer}
