//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

//metodos
const mysqlGetEmail=async()=>{
    const query=`SELECT mp_ci_email.COD_EMAIL,mp_ci_email.DES_EMAIL,mp_ci_personas.PRIMER_NOM_PERSONA,mp_ci_personas.COD_PERSONA,
     mp_ci_personas.SEGUNDO_NOM_PERSONA FROM mp_ci_email INNER JOIN mp_ci_personas ON mp_ci_personas.COD_PERSONA= mp_ci_email.COD_PERSONA`
    const data=await queryTemplate(query);
    return data;
}


const mysqlPostEmail=async(desEmail,codPersona)=>{

    const query=`CALL INS_EMAIL('${desEmail}','${codPersona}')`
    const data= await queryTemplate(query);
    return data;
}


const mysqlPutEmail=async(codEmail,codPersona,desEmail)=>{
    
    const query=`CALL UPDAT_EMAIL( '${codEmail}','${codPersona}','${desEmail}')`
    const data= await queryTemplate(query);
    return data;
}

const mysqlDeleteEmail=async(codEmail)=>{
    
    const query=`CALL DELET_EMAIL( '${codEmail}')`
    const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetEmail,mysqlPostEmail,mysqlPutEmail,mysqlDeleteEmail}
