const db=require("../db/conexion") //importar conexion para comunicar API con el servidor
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetMarcas=async()=>{ //metodo get(no requiere parametros)

        const query=`SELECT mprod_ci_marcas.COD_MARCA,msuc_ci_sucursales.NOM_SUCURSAL,
        mprod_ci_marcas.DES_MARCA
         FROM mprod_ci_marcas
         INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mprod_ci_marcas.COD_SUCURSAL` //select normal
        const data= await queryTemplate(query); //data=nuestro amigo fiel que siempre va ir (async y await siempre juntos)
        return data;
}

const mysqlPostMarcas=async(desMarca,codSucursal)=>{
    
    const query=`CALL INS_MARCAS('${desMarca}','${codSucursal}')`
    const data= await queryTemplate(query);
    return data;
}

const mysqlPutMarcas=async(codMarca,desMarca)=>{

    const query=`CALL UPDAT_MARCAS('${codMarca}','${desMarca}')`
    const data= await queryTemplate(query);
    return data;
    }


module.exports={mysqlGetMarcas,mysqlPostMarcas,mysqlPutMarcas}
