const db=require("../db/conexion") //importar conexion para comunicar API con el servidor
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetCierres=async()=>{ //metodo get(no requiere parametros)

        const query=`SELECT * FROM  mc_ci_cierres` //select normal
        const data= await queryTemplate(query); //data=nuestro amigo fiel que siempre va ir (async y await siempre juntos)
        return data;
}

const mysqlPostCierres=async(efectInicial,totVenta,totCompra,efectFinal,efectSobrant,efectFaltant,granTot,codUsuario,codCaja,codSucursal,codAjuste)=>{
    
    const query=`CALL INS_CIERRES('${efectInicial}','${totVenta}','${totCompra}','${efectFinal}','${efectSobrant}','${efectFaltant}','${granTot}','${codUsuario}','${codCaja}','${codSucursal}','${codAjuste}')`
    const data= await queryTemplate(query);
    return data;
}
const mysqlPutCierres=async(codCierre,efectInicial,totVenta,totCompra,efectFinal,efectSobrant,efectFaltant,granTot,codUsuario,codCaja,codSucursal,codAjuste)=>{

const query=`CALL UPDAT_CIERRES('${codCierre}','${efectInicial}','${totVenta}','${totCompra}','${efectFinal}','${efectSobrant}','${efectFaltant}','${granTot}','${codUsuario}','${codCaja}','${codSucursal}','${codAjuste}')`
const data= await queryTemplate(query);
return data;
}

module.exports={mysqlGetCierres,mysqlPostCierres,mysqlPutCierres}
