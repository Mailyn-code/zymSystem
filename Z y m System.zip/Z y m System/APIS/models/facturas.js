//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")


//metodos
const mysqlGetFactura=async(idUsuario)=>{
    const query = idUsuario
    ? `SELECT mi_ci_facturas.COD_FACTURA,mi_ci_facturas.COD_BARRA_PRODUCTO,msuc_ci_sucursales.NOM_SUCURSAL,
    mi_ci_facturas.CAN_PROD_FACTURA,mi_ci_facturas.PRE_PROD_FACTURA,mi_ci_facturas.TOT_FACTURA,
    mprod_ci_productos.COD_PRODUCTO,mi_ci_facturas.RTN_FACTURA,mp_ci_personas.PRIMER_NOM_PERSONA,
    mi_ci_forma_pago.DES_FORMA_PAGO,mi_ci_facturas.MONTO_TARJETA,mi_ci_facturas.EFECTIVO_RECIBIDO_FACTURA,
    mi_ci_facturas.CAMBIO_EFECTIVO_FACTURA,mi_ci_facturas.FEC_FACTURA
    FROM mi_ci_facturas
     INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_facturas.COD_SUCURSAL
     INNER JOIN mprod_ci_productos ON mprod_ci_productos.COD_PRODUCTO= mi_ci_facturas.COD_PRODUCTO
     INNER JOIN mi_ci_forma_pago ON mi_ci_forma_pago.COD_FORMA_PAGO= mi_ci_facturas.COD_FORMA_PAGO
     INNER JOIN mp_ci_personas ON mp_ci_personas.COD_PERSONA= mi_ci_facturas.COD_PERSONA WHERE mi_ci_facturas.COD_USUARIO=${idUsuario}`
     : 
     `SELECT mi_ci_facturas.COD_FACTURA,mi_ci_facturas.COD_BARRA_PRODUCTO,msuc_ci_sucursales.NOM_SUCURSAL,
    mi_ci_facturas.CAN_PROD_FACTURA,mi_ci_facturas.PRE_PROD_FACTURA,mi_ci_facturas.TOT_FACTURA,
    mprod_ci_productos.COD_PRODUCTO,mi_ci_facturas.RTN_FACTURA,mp_ci_personas.PRIMER_NOM_PERSONA,
    mi_ci_forma_pago.DES_FORMA_PAGO,mi_ci_facturas.MONTO_TARJETA,mi_ci_facturas.EFECTIVO_RECIBIDO_FACTURA,
    mi_ci_facturas.CAMBIO_EFECTIVO_FACTURA,mi_ci_facturas.FEC_FACTURA
    FROM mi_ci_facturas
     INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_facturas.COD_SUCURSAL
     INNER JOIN mprod_ci_productos ON mprod_ci_productos.COD_PRODUCTO= mi_ci_facturas.COD_PRODUCTO
     INNER JOIN mi_ci_forma_pago ON mi_ci_forma_pago.COD_FORMA_PAGO= mi_ci_facturas.COD_FORMA_PAGO
     INNER JOIN mp_ci_personas ON mp_ci_personas.COD_PERSONA= mi_ci_facturas.COD_PERSONA`
     const data = await queryTemplate(query);
     return data;
}

const mysqlPostFactura=async(codBarraProd,loteProd,canProdFactura,preProdFactura,totFactura,efecReciFactura,cambioEfecFactura,rtnFactura,codProducto,codFormaPago,codUsuario,codSucursal,codPersona,monTarjeta)=>{

    const query=`CALL INS_Factura('${codBarraProd}','${loteProd}', '${canProdFactura}','${preProdFactura}','${totFactura}','${efecReciFactura}','${cambioEfecFactura}','${rtnFactura}','${codProducto}','${codFormaPago}','${codUsuario}','${codSucursal}','${codPersona}','${monTarjeta}')`
    const data= await queryTemplate(query);
    return data;
}

const mysqlPutFactura=async(codFactura,codBarraProd,loteProd,canProdFactura,preProdFactura,totFactura,efecReciFactura,cambioEfecFactura,rtnFactura,codProducto,codFormaPago,codPersona,monTarjeta)=>{
    
    const query=`CALL UPDAT_FACTURAS( '${codFactura}','${codBarraProd}','${loteProd}', '${canProdFactura}','${preProdFactura}','${totFactura}','${efecReciFactura}','${cambioEfecFactura}','${rtnFactura}','${codProducto}','${codFormaPago}','${codPersona}','${monTarjeta}')`
    const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetFactura,mysqlPostFactura,mysqlPutFactura}
