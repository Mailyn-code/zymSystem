//hacer las consultas
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetRoles=async()=>{

        const query=`SELECT ms_ci_rol.COD_ROL,ms_ci_rol.DES_ROL,msuc_ci_sucursales.NOM_SUCURSAL FROM ms_ci_rol INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= ms_ci_rol.COD_SUCURSAL`
        const data= await queryTemplate(query);
        return data;
}

const mysqlPostRoles=async(desRol,codSucursal)=>{

        const query=`CALL INS_ROL('${desRol}','${codSucursal}')`
        const data= await queryTemplate(query);
        return data;
}


module.exports={mysqlGetRoles,mysqlPostRoles}
