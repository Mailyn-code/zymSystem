//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

//metodos
const mysqlGetSucursal=async()=>{
    const query=`SELECT * FROM msuc_ci_sucursales`
    const data=await queryTemplate(query);
    return data;
}

const mysqlPostSucursal=async(nomSucursal,dirSucursal)=>{

    const query=`CALL INS_sucursal('${nomSucursal}','${dirSucursal}')`
    const data= await queryTemplate(query);
    return data;
}

const mysqlPutSucursal=async(codSucursal,nomSucursal,dirSucursal)=>{
    
    const query=`CALL UPDAT_SUCURSALES( '${codSucursal}','${nomSucursal}','${dirSucursal}')`
    const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetSucursal,mysqlPostSucursal,mysqlPutSucursal}