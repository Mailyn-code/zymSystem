//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

//metodos
const mysqlGetTelefonos=async()=>{
    const query=`SELECT mp_ci_telefonos.COD_TELEFONO,mp_ci_telefonos.NUM_TELEFONO,mp_ci_telefonos.COD_PERSONA,
    mp_ci_personas.PRIMER_NOM_PERSONA, mp_ci_personas.PRIMER_APELLIDO_PERSONA, 
    mp_ci_telefonos.TIPO_TELEFONO
    FROM mp_ci_telefonos INNER JOIN mp_ci_personas ON mp_ci_personas.COD_PERSONA= mp_ci_telefonos.COD_PERSONA`
    const data=await queryTemplate(query);
    return data;
}


const mysqlPostTelefonos=async(numTel,tipoTel,codPersona)=>{

    const query=`CALL INS_TELEFONOS('${numTel}','${tipoTel}', '${codPersona}')`
    const data= await queryTemplate(query);
    return data;
}

const mysqlPutTelefonos=async(codPersona,numTel,tipoTel)=>{
    
    const query=`CALL UPDAT_TELEFONOS( '${codPersona}','${numTel}','${tipoTel}')`
    const data= await queryTemplate(query);
    return data;
}

const mysqlDeleteTelefonos=async(codTelefono)=>{
    
    const query=`CALL DELET_TELEFONOS( '${codTelefono}')`
    const data= await queryTemplate(query);
    return data;
}
module.exports={mysqlGetTelefonos,mysqlPostTelefonos,mysqlPutTelefonos,mysqlDeleteTelefonos}

