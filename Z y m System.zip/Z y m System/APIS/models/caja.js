//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

//metodos
const mysqlGetCaja=async()=>{
    const query=`SELECT * FROM mc_ci_caja`
    const data=await queryTemplate(query);
    return data;
}

const mysqlPostCaja=async(saldInicialCaja,saldAnteriorCaja,saldoFinalCaja,saldoCaja,codUsr,codSucursal)=>{

    const query=`CALL INS_caja('${saldInicialCaja}','${saldAnteriorCaja}', '${saldoFinalCaja}','${saldoCaja}','${codUsr}','${codSucursal}')`
    const data= await queryTemplate(query);
    return data;
}

const mysqlPutCaja=async(codCaja,saldInicialCaja,saldAnteriorCaja,saldoFinalCaja,saldoCaja)=>{
    
    const query=`CALL UPDAT_CAJA( '${codCaja}','${saldInicialCaja}','${saldAnteriorCaja}', '${saldoFinalCaja}','${saldoCaja}')`
    const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetCaja,mysqlPostCaja,mysqlPutCaja}
