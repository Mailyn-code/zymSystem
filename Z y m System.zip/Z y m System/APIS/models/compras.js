//hacer las consultas
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetCompras=async(idUsuario)=>{
        const query=idUsuario
        ? `SELECT mi_ci_compras.COD_COMPRA,mi_ci_compras.COD_BARRA_PRODUCTO,msuc_ci_sucursales.NOM_SUCURSAL,msuc_ci_sucursales.COD_SUCURSAL,
        mi_ci_compras.DES_COMPRA,mi_ci_compras.CAN_COMPRA,mi_ci_compras.COSTO_UNITARIO,mi_ci_compras.TOT_COMPRA,mi_ci_compras.COD_USUARIO,
        mi_ci_compras.LOTE_TOTAL_COMPRA,mi_ci_compras.LOTE_COMPRA,mi_ci_compras.FEC_ELABORACION_PRODUCTO,mi_ci_compras.FEC_CADUCIDAD,
        mi_ci_compras.FEC_COMPRA,mp_ci_personas.PRIMER_NOM_PERSONA,mp_ci_personas.COD_PERSONA,mprod_ci_productos.COD_PRODUCTO
        FROM mi_ci_compras
         INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_compras.COD_SUCURSAL
         INNER JOIN mp_ci_personas ON mp_ci_personas.COD_PERSONA= mi_ci_compras.COD_PERSONA
         INNER JOIN mprod_ci_productos ON mprod_ci_productos.COD_PRODUCTO= mi_ci_compras.COD_PRODUCTO  WHERE mi_ci_compras.COD_USUARIO=${idUsuario}`
         : `SELECT mi_ci_compras.COD_COMPRA,mi_ci_compras.COD_BARRA_PRODUCTO,msuc_ci_sucursales.NOM_SUCURSAL,msuc_ci_sucursales.COD_SUCURSAL,
         mi_ci_compras.DES_COMPRA,mi_ci_compras.CAN_COMPRA,mi_ci_compras.COSTO_UNITARIO,mi_ci_compras.TOT_COMPRA,mi_ci_compras.COD_USUARIO,
         mi_ci_compras.LOTE_TOTAL_COMPRA,mi_ci_compras.LOTE_COMPRA,mi_ci_compras.FEC_ELABORACION_PRODUCTO,mi_ci_compras.FEC_CADUCIDAD,
         mi_ci_compras.FEC_COMPRA,mp_ci_personas.PRIMER_NOM_PERSONA,mp_ci_personas.COD_PERSONA,mprod_ci_productos.COD_PRODUCTO
         FROM mi_ci_compras
          INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_compras.COD_SUCURSAL
          INNER JOIN mp_ci_personas ON mp_ci_personas.COD_PERSONA= mi_ci_compras.COD_PERSONA
          INNER JOIN mprod_ci_productos ON mprod_ci_productos.COD_PRODUCTO= mi_ci_compras.COD_PRODUCTO`; 
          
  const data = await queryTemplate(query);
  return data;
};
     

const mysqlPostCompras=async(codBarraProducto,desCompra,canCompra,fecElaboracion,fecCaducidad,loteCompra,loteTotal,totalCompra,codUsuario,codSucursal,codProducto,codPersona,costoUnitario)=>{
    
        const query=`CALL INS_COMPRAS('${codBarraProducto}','${desCompra}','${canCompra}','${fecElaboracion}','${fecCaducidad}','${loteCompra}','${loteTotal}','${totalCompra}','${codUsuario}','${codSucursal}','${codProducto}','${codPersona}','${costoUnitario}')`
        const data= await queryTemplate(query);
        return data;
}
const mysqlPutCompras=async(codCompra,codBarraProducto,desCompra,canCompra,fecElaboracion,fecCaducidad,loteCompra,loteTotal,totalCompra,codUsuario,codSucursal,codProducto,codPersona,costoUnitario)=>{
    
    const query=`CALL UPDAT_COMPRAS('${codCompra}','${codBarraProducto}','${desCompra}','${canCompra}','${fecElaboracion}','${fecCaducidad}','${loteCompra}','${loteTotal}','${totalCompra}','${codUsuario}','${codSucursal}','${codProducto}','${codPersona}','${costoUnitario}')`
    const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetCompras,mysqlPostCompras,mysqlPutCompras}
