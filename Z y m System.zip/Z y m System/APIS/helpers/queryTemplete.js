const db=require("../db/conexion")

const queryTemplate=async(query)=>{
    let res;
    try {
        const conn=await db.getConnection()
        const [data]=await conn.execute(query)
        conn.release();
       res={data,success:true}
    } catch (error) {
        res={data:[],success:false}
    }
    return res;
}
module.exports={queryTemplate};