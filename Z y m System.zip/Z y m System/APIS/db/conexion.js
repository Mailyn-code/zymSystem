//const config = require("config");
const mysql = require("mysql2");
const local = true;

const configMysqlRemote = {
  host: local ? "localhost" : "",
  user: local ? "root" : "",
  password: local ? "" : "",
  database: local ? "zymfinal" : "",
  port: local ? "3306" : "",
  
};

function connection() {
  try {
    const pool = mysql.createPool({
      ...configMysqlRemote,
    });

    const promisePool = pool.promise();

    return promisePool;
  } catch (error) {
    return console.log(`Could not connect - ${error}`);
  }
}

const pool = connection();

module.exports = pool;
