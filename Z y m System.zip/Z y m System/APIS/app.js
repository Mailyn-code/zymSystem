const Server=require("./models/server");

const nuevoServer= new Server();

nuevoServer.listen();