//hacer las consultas
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetUser=async()=>{

        const query=`SELECT ms_ci_usuarios.COD_USUARIO,mp_ci_personas.PRIMER_NOM_PERSONA,mp_ci_personas.COD_PERSONA,msuc_ci_sucursales.NOM_SUCURSAL,msuc_ci_sucursales.COD_SUCURSAL,
         mp_ci_personas.PRIMER_APELLIDO_PERSONA,ms_ci_rol.DES_ROL,ms_ci_rol.COD_ROL,ms_ci_usuarios.USUARIO_USR, ms_ci_usuarios.IND_USR,ms_ci_usuarios.COD_USUARIO,
         ms_ci_usuarios.PASSWORD_USR 
         FROM ms_ci_usuarios 
         INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= ms_ci_usuarios.COD_SUCURSAL 
         INNER JOIN ms_ci_rol ON ms_ci_rol.COD_ROL= ms_ci_usuarios.COD_ROL 
         INNER JOIN mp_ci_personas ON mp_ci_personas.COD_PERSONA= ms_ci_usuarios.COD_PERSONA`;
        const data= await queryTemplate(query);
        return data;
}

const mysqlPostUser=async(codPersona,usuario,ind,contraseña,codRol,codSucursal)=>{

        const query=`CALL INS_USUARIO('${codPersona}','${usuario}','${ind}','${contraseña}','${codRol}','${codSucursal}')`
        const data= await queryTemplate(query);
        return data;
}


const mysqlPutUser=async(codUsuario,usuario,ind,contraseña,codRol,codSucursal)=>{
 
    const query=`CALL UPDAT_USUARIOS('${codUsuario}','${usuario}','${ind}','${contraseña}','${codRol}','${codSucursal}')`
    const data= await queryTemplate(query);
    return data;
}
module.exports={mysqlGetUser,mysqlPostUser,mysqlPutUser}
