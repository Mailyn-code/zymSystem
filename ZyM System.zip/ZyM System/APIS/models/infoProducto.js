//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

//metodos
const mysqlGetInfoProducto=async(codProducto)=>{

    const query = codProducto
    ? `SELECT mprod_ci_productos.COD_PRODUCTO,mprod_ci_productos.DES_PRODUCTO,mprod_ci_productos.NOM_PRODUCTO, mprod_ci_productos.COD_DE_BARRA_PRODUCTO,
    mi_ci_almacen_productos.CODIGO_LOTE,mi_ci_inventarios.PRECIO_VENTA
     FROM mprod_ci_productos 
     INNER JOIN mi_ci_almacen_productos ON mi_ci_almacen_productos.COD_PRODUCTO = mprod_ci_productos.COD_PRODUCTO
     INNER JOIN mi_ci_inventarios ON mi_ci_inventarios.COD_PRODUCTO = mprod_ci_productos.COD_PRODUCTO where mprod_ci_productos.COD_PRODUCTO=${codProducto}`
    : `SELECT mprod_ci_productos.COD_PRODUCTO,mprod_ci_productos.DES_PRODUCTO,mprod_ci_productos.NOM_PRODUCTO, mprod_ci_productos.COD_DE_BARRA_PRODUCTO,
    mi_ci_almacen_productos.CODIGO_LOTE,mi_ci_inventarios.PRECIO_VENTA
     FROM mprod_ci_productos 
     INNER JOIN mi_ci_almacen_productos ON mi_ci_almacen_productos.COD_PRODUCTO = mprod_ci_productos.COD_PRODUCTO
     INNER JOIN mi_ci_inventarios ON mi_ci_inventarios.COD_PRODUCTO = mprod_ci_productos.COD_PRODUCTO`
    const data = await queryTemplate(query);
  return data;
};
module.exports={mysqlGetInfoProducto}
  