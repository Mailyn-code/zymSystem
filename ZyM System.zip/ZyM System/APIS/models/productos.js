//hacer las consultas
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetProductos=async()=>{

        const query=`SELECT mprod_ci_productos.COD_PRODUCTO,msuc_ci_sucursales.NOM_SUCURSAL,
        mprod_ci_productos.DES_PRODUCTO,msuc_ci_sucursales.COD_SUCURSAL,
        mprod_ci_productos.NOM_PRODUCTO,mprod_ci_marcas.DES_MARCA,mprod_ci_marcas.COD_MARCA,
         mprod_ci_productos.COD_DE_BARRA_PRODUCTO,mprod_ci_productos.IMG_PRODUCTO,
        ms_ci_usuarios.USUARIO_USR, ms_ci_usuarios.COD_USUARIO,
        mprod_ci_presentacion.DES_PRESENTACION,mprod_ci_presentacion.COD_PRESENTACION,mprod_ci_categorias.DES_CATEGORIA,mprod_ci_categorias.COD_CATEGORIA
         FROM mprod_ci_productos 
           INNER JOIN ms_ci_usuarios ON ms_ci_usuarios.COD_USUARIO = mprod_ci_productos.COD_USUARIO
         INNER JOIN mprod_ci_marcas ON mprod_ci_marcas.COD_MARCA = mprod_ci_productos.COD_MARCA
         INNER JOIN mprod_ci_categorias ON mprod_ci_categorias.COD_CATEGORIA = mprod_ci_productos.COD_CATEGORIA 
         INNER JOIN mprod_ci_presentacion ON mprod_ci_presentacion.COD_PRESENTACION = mprod_ci_productos.COD_PRESENTACION 
         INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mprod_ci_productos.COD_SUCURSAL`
        const data= await queryTemplate(query);
        return data;
}

const mysqlPostProductos=async(codBarraProducto,nomProducto,desProducto,imgProducto,codUsuario,codCategoria,codMarca,codPresentacion,codSucursal)=>{
    
        const query=`CALL INS_producto('${codBarraProducto}','${nomProducto}','${desProducto}','${imgProducto}','${codUsuario}','${codCategoria}','${codMarca}','${codPresentacion}','${codSucursal}')`
        const data= await queryTemplate(query);
        return data;
}
const mysqlPutProductos=async(codProducto,codBarraProducto,nomProducto,desProducto,imgProducto,codUsuario,codCategoria,codMarca,codPresentacion)=>{
    
    const query=`CALL UPDAT_PRODUCTO('${codProducto}','${codBarraProducto}','${nomProducto}','${desProducto}','${imgProducto}','${codUsuario}','${codCategoria}','${codMarca}','${codPresentacion}')`
    const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetProductos,mysqlPostProductos,mysqlPutProductos}
