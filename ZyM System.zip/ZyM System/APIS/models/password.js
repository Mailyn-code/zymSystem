//hacer las consultas
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetPassword=async()=>{

        const query=`SELECT * FROM  ms_ci_reset_password`
        const data= await queryTemplate(query);
        return data;
}

const mysqlPostPassword=async(codUsuario,desPassword,token,codigo,email)=>{
    
        const query=`CALL INS_RESET('${codUsuario}','${desPassword}','${token}','${codigo}','${email}')`
        const data= await queryTemplate(query);
        return data;
}

module.exports={mysqlGetPassword,mysqlPostPassword}