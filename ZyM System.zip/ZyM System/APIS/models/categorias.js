//hacer las consultas
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetCategorias=async()=>{

        const query=`SELECT mprod_ci_categorias.COD_CATEGORIA,msuc_ci_sucursales.NOM_SUCURSAL,msuc_ci_sucursales.COD_SUCURSAL,
        mprod_ci_categorias.DES_CATEGORIA,mprod_ci_categorias.NUM_ESTANTE_CATEGORIA,
        mprod_ci_categorias.IND_CATEGORIA
         FROM mprod_ci_categorias 
         INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mprod_ci_categorias.COD_SUCURSAL`
        const data= await queryTemplate(query);
        return data;
}

const mysqlPostCategorias=async(desCategoria,numEstanteCategoria,indCategoria,codSucursal)=>{
    
        const query=`CALL INS_CATEGORIA('${desCategoria}','${numEstanteCategoria}','${indCategoria}','${codSucursal}')`
        const data= await queryTemplate(query);
        return data;
}
const mysqlPutCategorias=async(codCategoria,desCategoria,numEstanteCategoria,indCategoria)=>{
        const query=`CALL UPDAT_CATEGORIAS('${codCategoria}','${desCategoria}','${numEstanteCategoria}','${indCategoria}')`
        const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetCategorias,mysqlPostCategorias,mysqlPutCategorias}