const { queryTemplate } = require("../helpers/queryTemplete");

//metodos
const mysqlEstadisticas = async () => {
  let res = { data: {}, success: false };

  const queryCountVentas = `SELECT COUNT(*) FROM mi_ci_ventas`;
  const dataCountVentas = await queryTemplate(queryCountVentas);

  const queryCountClientes = `SELECT COUNT(*) FROM mp_ci_personas WHERE mp_ci_personas.TIPO_PERSONA="CLIENTE"`;
  const dataCountClientes = await queryTemplate(queryCountClientes);

  const queryCountCompras = `SELECT COUNT(*) FROM mi_ci_compras`;
  const dataCountCompras = await queryTemplate(queryCountCompras);

  const queryCountProductos = `SELECT COUNT(*) FROM mprod_ci_productos`;
  const dataCountProductos = await queryTemplate(queryCountProductos);

  const coutVentas = dataCountVentas.data[0]["COUNT(*)"];
  const coutClientes = dataCountClientes.data[0]["COUNT(*)"];
  const coutCompras = dataCountCompras.data[0]["COUNT(*)"];
  const coutProductos = dataCountProductos.data[0]["COUNT(*)"];

  res = {
    data: { coutVentas, coutClientes, coutCompras, coutProductos },
    success: true,
  };

  return res;
};

module.exports = { mysqlEstadisticas };
