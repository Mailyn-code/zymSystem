const db=require("../db/conexion") //importar conexion para comunicar API con el servidor
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetDireccion=async()=>{ //metodo get(no requiere parametros)

        const query=`SELECT mp_ci_direccion.COD_DIR,mp_ci_direccion.DES_DIR,mp_ci_personas.PRIMER_NOM_PERSONA, mp_ci_personas.COD_PERSONA,
        mp_ci_personas.PRIMER_APELLIDO_PERSONA 
        FROM mp_ci_direccion INNER JOIN mp_ci_personas ON mp_ci_personas.COD_PERSONA= mp_ci_direccion.COD_PERSONA` //select normal
        const data= await queryTemplate(query); //data=nuestro amigo fiel que siempre va ir (async y await siempre juntos)
        return data;
}

const mysqlPostDireccion=async(desDireccion,codPersona)=>{
    
    const query=`CALL INS_DIRECCION('${desDireccion}','${codPersona}')`
    const data= await queryTemplate(query);
    return data;
}

const mysqlPutDireccion=async(codDireccion,desDireccion,codPersona)=>{

    const query=`CALL UPDAT_DIRECCION('${codDireccion}','${desDireccion}','${codPersona}')`
    const data= await queryTemplate(query);
    return data;
    }

const mysqlDeleteDireccion=async(codDireccion)=>{

const query=`CALL DELET_DIRECCION('${codDireccion}')`
const data= await queryTemplate(query);
return data;
}

module.exports={mysqlGetDireccion,mysqlPostDireccion,mysqlPutDireccion,mysqlDeleteDireccion}
