const routersProductos=require("../routes/productos");
const routersRoles=require("../routes/roles");
const routersPersonas=require("../routes/personas");
const routersCompras=require("../routes/compras");
const routersCategorias=require("../routes/categorias");
const routersPresentacion=require("../routes/presentacion");
const routersPassword=require("../routes/password");
const routersCierres=require("../routes/cierres");
const routersDireccion=require("../routes/direccion");
const routersMarcas=require("../routes/marcas");
const routersSucursales=require("../routes/sucursales");
const routersCaja=require("../routes/caja");
const routersTelefonos=require("../routes/telefonos");
const routersFacturas=require("../routes/facturas");
const routersAjustes=require("../routes/ajustes");
const routersEmail=require("../routes/email");
const routersUsuarios=require("../routes/user");
const routersInventario=require("../routes/inventario");
const routersAlmacen=require("../routes/almacen");
const routersVentas=require("../routes/ventas");
const routersFormaPago=require("../routes/formaPago");
const routersValidarUsuario=require("../routes/validarUsuario");
const routersProductosPorVencer=require("../routes/productosPorVencer");
const routersProductosAgotados=require("../routes/productosAgotados");
const routersEstadisticas = require("../routes/estadisticas");
const routersInfoProducto = require("../routes/infoProducto");


const cors = require('cors');
const express = require('express')//importar express
const db=require("../db/conexion")

class Server{

    constructor(){
        this.puerto=8082;
        
        //agrupa las caracterosticas de express en una variable
        this.app=express();
        this.dbConexion();
        this.middlewares(); 
        this.routes();
        

    }
    middlewares(){
        //es middlewares para usar cors
        this.app.use(cors());
//middlewares para que lectura y parseo del body
        this.app.use(express.json());

    }
    routes(){
this.app.use("/api/roles",routersRoles);
this.app.use("/api/productos",routersProductos);
this.app.use("/api/personas",routersPersonas);
this.app.use("/api/compras",routersCompras);
this.app.use("/api/categorias",routersCategorias);
this.app.use("/api/presentacion",routersPresentacion);
this.app.use("/api/password",routersPassword);
this.app.use("/api/cierres",routersCierres);
this.app.use("/api/direccion",routersDireccion);
this.app.use("/api/marcas",routersMarcas);
this.app.use("/api/ajustes",routersAjustes);
this.app.use("/api/caja",routersCaja);
this.app.use("/api/email",routersEmail);
this.app.use("/api/facturas",routersFacturas);
this.app.use("/api/sucursales",routersSucursales);
this.app.use("/api/telefonos",routersTelefonos);
this.app.use("/api/usuarios",routersUsuarios);
this.app.use("/api/inventario",routersInventario);
this.app.use("/api/almacen",routersAlmacen);
this.app.use("/api/ventas",routersVentas);
this.app.use("/api/formaPago",routersFormaPago);
this.app.use("/api/validarUsuario", routersValidarUsuario);
this.app.use("/api/productosPorVencer", routersProductosPorVencer);
this.app.use("/api/productosAgotados", routersProductosAgotados);
this.app.use("/api/estadisticas", routersEstadisticas);
this.app.use("/api/infoProducto", routersInfoProducto);

    }
    //trabaja con promesas por eso se coloca async
  
   async dbConexion(){
try {
    await db.getConnection();
    console.log("conexion exitosa")
        
    } catch (error) {
       console.log("Error de conexion",error.message) 
    }


    }
    listen(){

       this.app.listen(this.puerto,()=>{console.log("Servidor Corriendo en el puerto",this.puerto)} ) 
    }

   


} 
module.exports = Server

