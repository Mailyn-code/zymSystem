const db = require("../db/conexion");
const { queryTemplate } = require("../helpers/queryTemplete");

const mysqlPostValidarUsuario = async (email) => {
  const query = `SELECT  ms_ci_usuarios.COD_USUARIO,ms_ci_usuarios.USUARIO_USR,ms_ci_usuarios.COD_PERSONA,ms_ci_usuarios.COD_SUCURSAL, ms_ci_rol.DES_ROL FROM ms_ci_usuarios INNER JOIN ms_ci_rol ON ms_ci_usuarios.COD_ROL = ms_ci_rol.COD_ROL WHERE USUARIO_USR="${email}"`;

  const data = await queryTemplate(query);
  return data;
};

module.exports = { mysqlPostValidarUsuario };