//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

//metodos
const mysqlGetAjustes=async()=>{
    const query=`SELECT * FROM mc_ci_ajustes`
    const data=await queryTemplate(query);
    return data;
}


const mysqlPostAjustes=async(tipAjuste,canAjuste,importAjuste,totAjuste,codUsr,codSucursal,codProducto)=>{

    const query=`CALL INS_ajustes('${tipAjuste}','${canAjuste}', '${importAjuste}','${totAjuste}','${codUsr}','${codSucursal}','${codProducto}')`
    const data= await queryTemplate(query);
    return data;
}

const mysqlPutAjustes=async(codAjuste,tipAjuste,canAjust,importAjuste,totAjuste,codProducto)=>{
    
    const query=`CALL UPDAT_AJUSTES( '${codAjuste}','${tipAjuste}','${canAjust}', '${importAjuste}','${totAjuste}','${codProducto}')`
    const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetAjustes,mysqlPostAjustes,mysqlPutAjustes}