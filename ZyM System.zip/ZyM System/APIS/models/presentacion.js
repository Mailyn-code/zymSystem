//hacer las consultas
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetPresentacion=async()=>{

        const query=`SELECT mprod_ci_presentacion.COD_PRESENTACION,msuc_ci_sucursales.NOM_SUCURSAL,
        mprod_ci_presentacion.DES_PRESENTACION,mprod_ci_presentacion.UNIDAD_DE_MEDICION,
        mprod_ci_presentacion.CANT_DE_MEDICION
         FROM mprod_ci_presentacion
         INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mprod_ci_presentacion.COD_SUCURSAL`
        const data= await queryTemplate(query);
        return data;
}

const mysqlPostPresentacion=async(desPresentacion,codSucursal,unidadMedicion,canMedicion)=>{
    
        const query=`CALL INS_PRESENTACION('${desPresentacion}','${codSucursal}','${unidadMedicion}','${canMedicion}')`
        const data= await queryTemplate(query);
        return data;
}
const mysqlPutPresentacion=async(codPresentacion,desPresentacion,unidadMedicion,canMedicion)=>{
        const query=`CALL UPDAT_PRESENTACION('${codPresentacion}','${desPresentacion}','${unidadMedicion}','${canMedicion}')`
        const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetPresentacion,mysqlPostPresentacion,mysqlPutPresentacion}