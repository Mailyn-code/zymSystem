//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

//metodos
const mysqlGetFormaPago=async()=>{
    const query=`SELECT mi_ci_forma_pago.COD_FORMA_PAGO,msuc_ci_sucursales.NOM_SUCURSAL, mi_ci_forma_pago.DES_FORMA_PAGO FROM mi_ci_forma_pago INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_forma_pago.COD_SUCURSAL`
    const data=await queryTemplate(query);
    return data;
}



module.exports={mysqlGetFormaPago}