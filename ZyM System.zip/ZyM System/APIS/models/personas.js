//hacer las consultas
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetPersonas=async()=>{

        const query=`SELECT mp_ci_personas.COD_PERSONA,mp_ci_personas.PRIMER_NOM_PERSONA, 
        msuc_ci_sucursales.NOM_SUCURSAL,msuc_ci_sucursales.COD_SUCURSAL, mp_ci_personas.PRIMER_APELLIDO_PERSONA,mp_ci_personas.SEGUNDO_APELLIDO_PERSONA,mp_ci_personas.FEC_NAC_PERSONA,mp_ci_personas.IMG_PERSONA,
         mp_ci_personas.SEGUNDO_NOM_PERSONA,mp_ci_personas.TEL,mp_ci_personas.DIR, 
         mp_ci_personas.EMAIL,mp_ci_personas.GENERO_PERSONA,mp_ci_personas.FEC_NAC_PERSONA,
          mp_ci_personas.TIPO_PERSONA, mp_ci_personas.TIPO_TELEFONO, mp_ci_personas.DNI
          FROM mp_ci_personas 
          INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mp_ci_personas.COD_SUCURSAL`
        const data= await queryTemplate(query);
        return data;
}

const mysqlPostPersonas=async(imgPersonas,primerNombre,segundoNombre,primerApellido,segundoApellido,dni,tel,tipoTelefono,dir,email,genero,fechaNacimiento,tipoPersona,codSucursal)=>{
    
        const query=`CALL INS_PERSONA('${imgPersonas}','${primerNombre}','${segundoNombre}','${primerApellido}','${segundoApellido}','${dni}','${tel}','${tipoTelefono}','${dir}','${email}','${genero}','${fechaNacimiento}','${tipoPersona}','${codSucursal}')`
        const data= await queryTemplate(query);
        return data;
}

const mysqlPutPersonas=async(codPersona,imgPersonas,primerNombre,segundoNombre,primerApellido,segundoApellido,dni,tel,dir,email,genero,fechaNacimiento,tipoPersona,tipoTelefono)=>{
    
    const query=`CALL UPDAT_PERSONAS('${codPersona}','${imgPersonas}','${primerNombre}','${segundoNombre}','${primerApellido}','${segundoApellido}','${dni}','${tel}','${dir}','${email}','${genero}','${fechaNacimiento}','${tipoPersona}','${tipoTelefono}')`
    const data= await queryTemplate(query);
    return data;
}

module.exports={mysqlGetPersonas,mysqlPostPersonas,mysqlPutPersonas}
