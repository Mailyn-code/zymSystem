//hacer las consultas conexion
const db=require("../db/conexion")
const {queryTemplate}=require("../helpers/queryTemplete")

const mysqlGetInventario=async(idUsuario)=>{

    const query = idUsuario
    ? `SELECT mi_ci_inventarios.COD_INVENTARIO,mprod_ci_productos.NOM_PRODUCTO,mprod_ci_productos.COD_PRODUCTO,mi_ci_inventarios.ENTRADA_PRODUCTO, msuc_ci_sucursales.NOM_SUCURSAL,mi_ci_inventarios.SALIDA_PRODUCTO,mi_ci_inventarios.STOCK,mi_ci_inventarios.PRECIO_VENTA, mi_ci_inventarios.TOTAL_INVENTARIO FROM mi_ci_inventarios INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_inventarios.COD_SUCURSAL INNER JOIN mprod_ci_productos ON mprod_ci_productos.COD_PRODUCTO= mi_ci_inventarios.COD_PRODUCTO WHERE mi_ci_inventarios.COD_USUARIO=${idUsuario}`
    : `SELECT mi_ci_inventarios.COD_INVENTARIO,mprod_ci_productos.NOM_PRODUCTO,mprod_ci_productos.COD_PRODUCTO,mi_ci_inventarios.ENTRADA_PRODUCTO, msuc_ci_sucursales.NOM_SUCURSAL,mi_ci_inventarios.SALIDA_PRODUCTO,mi_ci_inventarios.STOCK,mi_ci_inventarios.PRECIO_VENTA, mi_ci_inventarios.TOTAL_INVENTARIO FROM mi_ci_inventarios INNER JOIN msuc_ci_sucursales ON msuc_ci_sucursales.COD_SUCURSAL= mi_ci_inventarios.COD_SUCURSAL INNER JOIN mprod_ci_productos ON mprod_ci_productos.COD_PRODUCTO= mi_ci_inventarios.COD_PRODUCTO`


    const data = await queryTemplate(query);
    return data;

};



module.exports={mysqlGetInventario}