const {Router}=require('express');
const {getCierres,postCierres,putCierres}=require('../controllers/cierres');

const router= Router();//metodo para definir las rutas para usarlas en postman

router.get("/",getCierres);//obtener
router.post("/",postCierres);
router.put("/",putCierres);
module.exports=router;

