
const {Router}=require('express');
const {getCompras,postCompras,putCompras}=require('../controllers/compras');

const router= Router();


router.get("/",getCompras);//obtener
router.post("/",postCompras);
router.put("/",putCompras);
module.exports=router;
