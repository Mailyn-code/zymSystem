const {Router}=require('express');
const {getTelefonos,postTelefonos, putTelefonos,deleteTelefonos}=require('../controllers/Telefonos');

const router= Router();


router.get("/",getTelefonos);//obtener
router.post("/",postTelefonos);
router.put("/",putTelefonos);
router.delete("/",deleteTelefonos);
module.exports=router;