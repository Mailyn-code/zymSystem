const {Router}=require('express');
const {getMarcas,postMarcas,putMarcas}=require('../controllers/marcas');

const router= Router();//metodo para definir las rutas para usarlas en postman

router.get("/",getMarcas);//obtener
router.post("/",postMarcas);
router.put("/",putMarcas);
module.exports=router;

