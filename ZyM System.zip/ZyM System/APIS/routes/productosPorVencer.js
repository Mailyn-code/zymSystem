
const {Router}=require('express');
const {getProductosPorVencer}=require('../controllers/productosPorVencer');

const router= Router();


router.get("/",getProductosPorVencer);//obtener

module.exports=router;
