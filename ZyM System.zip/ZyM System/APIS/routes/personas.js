
const {Router}=require('express');
const {getPersonas,postPersonas,putPersonas}=require('../controllers/personas');

const router= Router();


router.get("/",getPersonas);//obtener
router.post("/",postPersonas);
router.put("/",putPersonas);
module.exports=router;