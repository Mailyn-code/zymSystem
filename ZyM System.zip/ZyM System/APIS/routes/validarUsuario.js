const { Router } = require("express");
const { postValidarUsuario } = require("../controllers/validarUsuario");

const router = Router();

router.post("/", postValidarUsuario); //obtener

module.exports = router;