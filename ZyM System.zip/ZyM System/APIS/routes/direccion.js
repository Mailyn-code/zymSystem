const {Router}=require('express');
const {getDireccion,postDireccion,putDireccion,deleteDireccion}=require('../controllers/direccion');

const router= Router();//metodo para definir las rutas para usarlas en postman

router.get("/",getDireccion);//obtener
router.post("/",postDireccion);
router.put("/",putDireccion);
router.delete("/",deleteDireccion);
module.exports=router;
