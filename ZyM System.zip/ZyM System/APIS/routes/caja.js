const {Router}=require('express');
const {getCaja,postCaja,putCaja}=require('../controllers/caja');

const router= Router();


router.get("/",getCaja);//obtener
router.post("/",postCaja);
router.put("/",putCaja);
module.exports=router;