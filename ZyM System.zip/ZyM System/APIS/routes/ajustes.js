const {Router}=require('express');
const {getAjuste,postAjuste,putAjuste}=require('../controllers/ajustes');

const router= Router();


router.get("/",getAjuste);//obtener
router.post("/",postAjuste);
router.put("/",putAjuste);
module.exports=router;