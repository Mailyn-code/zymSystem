const {Router}=require('express');
const {getInventario}=require('../controllers/inventario');

const router= Router();


router.get("/",getInventario);//obtener
module.exports=router;