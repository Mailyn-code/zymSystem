const {Router}=require('express');
const {getVentas}=require('../controllers/ventas');

const router= Router();


router.get("/",getVentas);//obtener
module.exports=router;



