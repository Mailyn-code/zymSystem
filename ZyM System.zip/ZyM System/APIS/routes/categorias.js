
const {Router}=require('express');
const {getCategorias, postCategorias, putCategorias}=require('../controllers/categorias');

const router= Router();


router.get("/",getCategorias);//obtener
router.post("/",postCategorias);
router.put("/",putCategorias);
module.exports=router;