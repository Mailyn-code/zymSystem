const { request, response } = require("express");
const {mysqlGetMarcas,mysqlPostMarcas,mysqlPutMarcas}=require("../models/marcas");

const getMarcas=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetMarcas()
   if(success){
    res.json({
        mensaje:"Marcas obtenidos con éxito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener las Marcas",
        success
        
       })
       
   }

} ;

const postMarcas=async(req=request ,res=response)=>{
   
    const {desMarca, codSucursal}=req.body;

    await mysqlPostMarcas(desMarca, codSucursal)
    res.json({
        mensaje:"Exito Post",
    })

    
} ;

const putMarcas=async(req=request ,res=response)=>{
   
    const {codMarca,desMarca}=req.body;

    await mysqlPutMarcas(codMarca,desMarca)
    res.json({
        mensaje:"Exito Put",
    })

} ;

module.exports={
    getMarcas,
    postMarcas,
    putMarcas,

}
