const { request, response } = require("express");
const {mysqlGetProductosPorVencer}=require("../models/productosPorVencer");


const getProductosPorVencer=async(req=request ,res=response)=>{
    
    const {data,success}=await mysqlGetProductosPorVencer()
    if(success){
     res.json({
         mensaje:"Información de Email obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de Email",
         success
         
        })
        
    }
 
} ;



module.exports= {
    getProductosPorVencer,
    }
     
    
    

