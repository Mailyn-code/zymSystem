
const { request, response } = require("express");
const {mysqlGetDireccion,mysqlPostDireccion,mysqlPutDireccion,mysqlDeleteDireccion}=require("../models/direccion");

const getDireccion=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetDireccion()
   if(success){
    res.json({
        mensaje:"Dirección obtenidos con éxito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener las direcciones",
        success
        
       })
       
   }

} ;

const postDireccion=async(req=request ,res=response)=>{
   
    const {desDireccion, codPersona}=req.body;

    await mysqlPostDireccion(desDireccion, codPersona)
    res.json({
        mensaje:"Exito Post",
    })

    
} ;


const putDireccion=async(req=request ,res=response)=>{
   
    const {codDireccion,desDireccion,codPersona}=req.body;

    await mysqlPutDireccion(codDireccion, desDireccion,codPersona)
    res.json({
        mensaje:"Exito Put",
    })

};


const deleteDireccion=async(req=request ,res=response)=>{
   
    const {codDireccion}=req.body;

    await mysqlDeleteDireccion(codDireccion)
    res.json({
        mensaje:"Exito Delete",
    })

} ;

module.exports={
    getDireccion,
    postDireccion,
    putDireccion,
    deleteDireccion,

}
