const { request, response } = require("express");
const { mysqlPostValidarUsuario } = require("../models/validarUsuario");

//Obtener Usuarios

const postValidarUsuario = async (req = request, res = response) => {
  const { email } = req.body;
  //const {usuario}=req.body;
  const { data, success } = await mysqlPostValidarUsuario(email);

  if (data.length > 0) {
    res.json({
      mensaje: "Usuario y Contraseña Correctos",
      data,
      success,
    });
  } else {
    res.json({
      mensaje: "Usuario y Contraseña Incorrectos",
      success: false,
    });
  }
};
//Insertar Usuarios

module.exports = {
  postValidarUsuario,
};