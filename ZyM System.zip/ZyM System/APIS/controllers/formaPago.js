const { request, response } = require("express");
const {mysqlGetFormaPago}=require("../models/formaPago");


const getFormaPago=async(req=request ,res=response)=>{
    
    const {data,success}=await mysqlGetFormaPago()
    if(success){
     res.json({
         mensaje:"Información de Formas de Pagó de Productos obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de Forma de Pagó de Productos",
         success
         
        })
        
    }
 
} ;

module.exports= {
    getFormaPago,
    }