
const { request, response } = require("express");
const {mysqlGetCierres,mysqlPostCierres,mysqlPutCierres}=require("../models/cierres");

const getCierres=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetCierres()
   if(success){
    res.json({
        mensaje:"Cierres obtenidos con éxito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener los cierres",
        success
        
       })
       
   }

} ;

const postCierres=async(req=request ,res=response)=>{
   
    const {efectInicial,totVenta,totCompra,efectFinal,efectSobrant,efectFaltant,granTot,codUsuario,codCaja,codSucursal,codAjuste}=req.body;

    await mysqlPostCierres(efectInicial,totVenta,totCompra,efectFinal,efectSobrant,efectFaltant,granTot,codUsuario,codCaja, codSucursal,codAjuste)
    res.json({
        mensaje:"Exito Post",
    })


} ;

const putCierres=async(req=request ,res=response)=>{
   
    const {codCierre,efectInicial,totVenta,totCompra,efectFinal,efectSobrant,efectFaltant,granTot,codUsuario,codCaja,codSucursal,codAjuste}=req.body;

    await mysqlPutCierres(codCierre,efectInicial, totVenta, totCompra, efectFinal, efectSobrant, efectFaltant, granTot, codUsuario, codCaja, codSucursal,codAjuste)
    res.json({
        mensaje:"Éxito Put",
    })

} ;

module.exports={
    getCierres,
    postCierres,
    putCierres,

}

