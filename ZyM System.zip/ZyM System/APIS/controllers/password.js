const { request, response } = require("express");
const {mysqlGetPassword,mysqlPostPassword}=require("../models/password");

const getResetPassword=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetPassword()
   if(success){
    res.json({
        mensaje:"Contraseñas Restauradas obtenidas con exito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener las Contraseñas Restauradas",
        success
        
       })
       
   }

} ;

const postResetPassword=async(req=request ,res=response)=>{
   
    const {codUsuario,desPassword,token,codigo,email}=req.body;

    await mysqlPostPassword(codUsuario,desPassword,token,codigo,email)
    res.json({
        mensaje:"Exito Post",
    })

} ;

module.exports={
    getResetPassword,
    postResetPassword,
}