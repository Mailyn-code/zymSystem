const { request, response } = require("express");
const {mysqlGetAjustes,mysqlPostAjustes,mysqlPutAjustes}=require("../models/ajustes");


const getAjuste=async(req=request ,res=response)=>{
    
    const {data,success}=await mysqlGetAjustes()
    if(success){
     res.json({
         mensaje:"Información de Ajuste obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de ajuste",
         success
         
        })
        
    }
 
} ;


const postAjuste=async(req=request ,res=response)=>{
   
    const {tipAjuste,canAjuste,importAjuste,totAjuste,codUsr,codSucursal,codProducto}=req.body;

    await mysqlPostAjustes(tipAjuste,canAjuste,importAjuste,totAjuste,codUsr,codSucursal,codProducto)
    res.json({
        mensaje:"Éxito Post",
    })

} ;

const putAjuste=async(req=request ,res=response)=>{
   
    const {codAjuste,tipAjuste,canAjust,importAjuste,totAjuste,codProducto}=req.body;

    await mysqlPutAjustes(codAjuste,tipAjuste,canAjust,importAjuste,totAjuste,codProducto)
    res.json({
        mensaje:"Éxito Put",
    })

} ;

module.exports= {
getAjuste,
postAjuste,
putAjuste,
}