const { request, response } = require("express");
const {mysqlGetUser,mysqlPostUser,mysqlPutUser}=require("../models/user");


//Obtener Usuarios

const getUser=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetUser()
   if(success){
    res.json({
        mensaje:"Usuarios obtenido con exito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener los usuarios",
        success
        
       })
       
   }

} ;
//Insertar Usuarios
const postUser=async(req=request ,res=response)=>{
   
    const {codPersona,usuario,ind,contraseña,codRol,codSucursal}=req.body;

    await mysqlPostUser(codPersona,usuario,ind,contraseña,codRol,codSucursal)
    res.json({
        mensaje:"Exito Post user",
    })

} ;

//Actualizar Usuarios

const putUser=async(req=request ,res=response)=>{

    const {codUsuario,usuario,ind,contraseña,codRol,codSucursal}=req.body;

    await mysqlPutUser(codUsuario,usuario,ind,contraseña,codRol,codSucursal)

    res.json({
        mensaje:"Exito put user",
    })
 
} ;

const deleteUser=(req=request ,res=response)=>{
    res.json({
        mensaje:"Exito Delete user",
    })

} ;

module.exports={
    getUser,
    postUser,
    putUser,
    deleteUser,

}