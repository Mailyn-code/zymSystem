const { request, response } = require("express");
const {mysqlGetInfoProducto}=require("../models/infoProducto");


const getInfoProducto=async(req=request ,res=response)=>{
    const { codProducto = null } = req.query;
    console.log(codProducto)
    const {data,success}=await mysqlGetInfoProducto(codProducto)
    if(success){
     res.json({
         mensaje:"Información de Almacén de Productos obtenida con éxito",
         data,
         success
     })
    }else{
        res.json({
         mensaje:"Se ha producido un error al obtener la información de Almacén de Productos",
         success
         
        })
        
    }
 
} ;

module.exports= {
    getInfoProducto,
    }
    