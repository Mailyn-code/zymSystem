const { request, response } = require("express");
const {mysqlGetProductos,mysqlPostProductos,mysqlPutProductos}=require("../models/productos");

const getProductos=async(req=request ,res=response)=>{
    
   const {data,success}=await mysqlGetProductos()
   if(success){
    res.json({
        mensaje:"Productos obtenidos con exito",
        data,
        success
    })
   }else{
       res.json({
        mensaje:"Se ha producido un error al obtener los Productos",
        success
        
       })
       
   }

} ;

const postProductos=async(req=request ,res=response)=>{
   
    const {codBarraProducto,nomProducto,desProducto,imgProducto,codUsuario,codCategoria,codMarca,codPresentacion,codSucursal}=req.body;

    await mysqlPostProductos(codBarraProducto,nomProducto,desProducto,imgProducto,codUsuario,codCategoria,codMarca,codPresentacion,codSucursal)
    res.json({
        mensaje:"Exito Post",
    })

} ;

const putProductos=async(req=request ,res=response)=>{
    const {codProducto,codBarraProducto,nomProducto,desProducto,imgProducto,codUsuario,codCategoria,codMarca,codPresentacion}=req.body;

await mysqlPutProductos(codProducto,codBarraProducto,nomProducto,desProducto,imgProducto,codUsuario,codCategoria,codMarca,codPresentacion)

    res.json({
        mensaje:"Exito Put",
    })

} ;

const deleteProductos=(req=request ,res=response)=>{
    res.json({
        mensaje:"Exito Delete",
    })

} ;

module.exports={
    getProductos,
    postProductos,
    putProductos,
    deleteProductos,

}