function generarPDF(){
const element = document.getElementById("imprimir");
html2pdf()
.from(element)
.save();



}