
  let apiUrl = "http://localhost:8082/api/marcas";
  let apiUrl1 = "http://localhost:8082/api/sucursales";
  const contenedor1 = document.querySelector("select");
const contenedor = document.querySelector("tbody");
let idRegistro;

let {codigoSucursal,descripcionMarca } =
      document.forms["formularioMarcas"];
      console.log(codigoSucursal,descripcionMarca)
      const btnGuardar = document.querySelector(".contentBtnGuardar");
let resultados = "";
let resultados1 = "";


const getMarcas = async () => {
  try {
    const response = await fetch(apiUrl);
    const marcas = await response.json();
    const { data, success } = marcas;
console.log(data)
    data.forEach((marca) => {
      const {
      COD_MARCA,  
      DES_MARCA,
      NOM_SUCURSAL,

      } = marca;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(marca)}</td>
       <td>${COD_MARCA}</td>
   <td>${DES_MARCA}</td>
     <td>${NOM_SUCURSAL}</td>
     <td>
    
        <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
     Actualizar
        </i>
      </button>
    </td> 
     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};




const getMarcasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/sucursales");
  const sucursales = await response.json();
  const { data, success } = sucursales;
  const contenedorSelect = document.querySelector("#codigoSucursal");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((sucursal) => {
    const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;

    resultadosSelect += `
 
   <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const postMarcas = async () => {
 
  try {

    if( codigoSucursal.value==="" || descripcionMarca.value===""){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      desMarca:descripcionMarca.value,
      codSucursal:codigoSucursal.value
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        desMarca:descripcionMarca.value,
        codSucursal:codigoSucursal.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }
};



const putMarcas= async (id = null, estado = null) => {
  try {

    console.log(idRegistro)
    let body;
    if (id) {
      const {
        DES_MARCA,
    COD_SUCURSAL,
      } = JSON.parse(id);

      body = {
        codMarca:idRegistro,
        desMarca:descripcionMarca.value,

      
      };
    } else {
      body = {
        codMarca:idRegistro,
        desMarca:descripcionMarca.value,

      };
    }

    console.log(body)
    const requestOptions = {
      method: "PUT",
      body: JSON.stringify(body),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
   location.reload();
  } catch (error) {
    console.log(error.message);
  }
};



const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postMarcas()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro
on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {
    COD_MARCA,
    DES_MARCA,
    COD_SUCURSAL,
  } = JSON.parse(id);

  descripcionMarca.value=DES_MARCA;
  codigoSucursal.value=COD_SUCURSAL;
  idRegistro=COD_MARCA


  btnGuardar.innerHTML = `  <button onclick="putMarcas()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});


getMarcas();
getMarcasSelect();