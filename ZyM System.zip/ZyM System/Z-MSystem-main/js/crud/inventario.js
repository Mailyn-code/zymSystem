let apiUrl = "http://localhost:8082/api/inventario";

const contenedor = document.querySelector("tbody");


let resultados = "";


const getInventario = async () => {
  try {
    const response = await fetch(apiUrl);
    const almacenes = await response.json();
    const { data, success } = almacenes;

   
    data.forEach((inventario) => {
     
      const {
        COD_INVENTARIO,
        NOM_PRODUCTO,
        ENTRADA_PRODUCTO,
        SALIDA_PRODUCTO,
        STOCK,
        PRECIO_VENTA,
        TOTAL_INVENTARIO,
        NOM_SUCURSAL,
       
      } = inventario;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(inventario)}</td>
      <td>${COD_INVENTARIO}</td>
      <td>${NOM_PRODUCTO}</td>
      <td>${ENTRADA_PRODUCTO}</td>
      <td>${SALIDA_PRODUCTO}</td>
      <td>${STOCK}</td>
      <td>${PRECIO_VENTA}</td>
      <td>${TOTAL_INVENTARIO}</td>
      <td>${NOM_SUCURSAL}</td>
     
     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;
  } catch (error) {
    console.log(error);
  }
};


getInventario();