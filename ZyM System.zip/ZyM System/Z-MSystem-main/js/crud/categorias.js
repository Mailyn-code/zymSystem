
  let apiUrl = "http://localhost:8082/api/categorias";
  let apiUrl1 = "http://localhost:8082/api/sucursales";
  const contenedor1 = document.querySelector("select");
const contenedor = document.querySelector("tbody");
const btnGuardar = document.querySelector(".contentBtnGuardar");
let idRegistro;
let {
  codigoCategoria,
  codigoSucursal,
  descripcionCategoria,
  numeroEstante,
  estadoCategoria,
} = document.forms["formularioCategorias"];

let resultados = "";
let resultados1 = "";

const getCategorias = async () => {
  try {

    const response = await fetch(apiUrl);
    const categorias = await response.json();
    const { data, success } = categorias;

    data.forEach((categoria) => {
      const {
        COD_CATEGORIA,
        DES_CATEGORIA,
        NUM_ESTANTE_CATEGORIA,
        IND_CATEGORIA,
        NOM_SUCURSAL,
      } = categoria;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(categoria)}</td>
       <td>${COD_CATEGORIA}</td>
   <td>${DES_CATEGORIA}</td>
     <td>${NUM_ESTANTE_CATEGORIA}</td>
     <td>${IND_CATEGORIA}</td>
     <td>${NOM_SUCURSAL}</td>
     <td>
   
     <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
     Actualizar
        </i>
      </button>
       </td>
     </tr>
                    `;
    });

    contenedor.innerHTML = resultados;



    
  } catch (error) {
    console.log(error);
  }
};




const getMarcasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/sucursales");
  const sucursales = await response.json();
  const { data, success } = sucursales;
  const contenedorSelect = document.querySelector("#codigoSucursal");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((sucursal) => {
    const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;

    resultadosSelect += `
 
   <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const postCategorias = async () => {
 
  try {

    if(codigoSucursal.value==="" || descripcionCategoria.value==="" ||  numeroEstante.value==="" ||
      estadoCategoria.value===""){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
    
    console.log("hola",{
     desCategoria:descripcionCategoria.value,
     numEstanteCategoria:numeroEstante.value,
     indCategoria:estadoCategoria.value,
     codSucursal:codigoSucursal.value
    })
    const requestOptions = {
      method: "POST",
        body: JSON.stringify({
          desCategoria:descripcionCategoria.value,
          numEstanteCategoria:numeroEstante.value,
          indCategoria:estadoCategoria.value,
          codSucursal:codigoSucursal.value
          
          
        }),
        headers: { "Content-type": "application/json; charset=UTF-8" },
      };
    

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }
};

const putCategorias= async (id = null, estado = null) => {
  try {
console.log("kkkkkkkkkkk")
    console.log(idRegistro)
    let body;
    if (id) {
      const {

        COD_CATEGORIA,
        DES_CATEGORIA,
        NUM_ESTANTE_CATEGORIA,
        IND_CATEGORIA,
        NOM_SUCURSAL
    

      } = JSON.parse(id);
   
      body = {
        codCategoria:idRegistro,
        desCategoria:descripcionCategoria.value,
        numEstanteCategoria:numeroEstante.value,
        indCategoria:estadoCategoria.value,
        codSucursal:codigoSucursal.value
      
  
      
      };
    } else {
      body = {
        codCategoria:idRegistro,
        desCategoria:descripcionCategoria.value,
        numEstanteCategoria:numeroEstante.value,
        indCategoria:estadoCategoria.value,
        codSucursal:codigoSucursal.value

      };
    }

    console.log(body)
    const requestOptions = {
      method: "PUT",
      body: JSON.stringify(body),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
  // location.reload();
  } catch (error) {
    console.log(error.message);
  }
};




const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postCategorias()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro
on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {
    COD_CATEGORIA,
    DES_CATEGORIA,
    NUM_ESTANTE_CATEGORIA,
    IND_CATEGORIA,
    COD_SUCURSAL,
  } = JSON.parse(id);

  codigoSucursal.value=COD_SUCURSAL;
  descripcionCategoria.value=DES_CATEGORIA;
  numeroEstante.value=NUM_ESTANTE_CATEGORIA;
  estadoCategoria.value=IND_CATEGORIA;
  idRegistro=COD_CATEGORIA;


  btnGuardar.innerHTML = `  <button onclick="putCategorias()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});


getCategorias();
getMarcasSelect();