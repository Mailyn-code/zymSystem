let apiUrl = "http://localhost:8082/api/usuarios";

const contenedor = document.querySelector("tbody");
let idRegistro;
let { codigoPersona,codigoRol,descripcionUsuario,nombreUsuario,estadoUsuario,contraseñaUsuario,codigoSucursal } =
document.forms["formularioUsuario"];
const btnGuardar = document.querySelector(".contentBtnGuardar");
let resultados = "";

const getUsuario= async() => {
  try {
    
  
  const response = await fetch(apiUrl);
  const usuario = await response.json();
  const { data, success } = usuario;

  data.forEach((usuario) => {
    const {
      COD_USUARIO,
      PRIMER_NOM_PERSONA,
      PRIMER_APELLIDO_PERSONA,
      USUARIO_USR,
      IND_USR,
      PASSWORD_USR,
      DES_ROL,
      NOM_SUCURSAL,
    } = usuario;

    resultados += `
    <tr>
    <td class="dataItem">${JSON.stringify(usuario)}</td>
     <td>${COD_USUARIO}</td>
     <td>${PRIMER_NOM_PERSONA  } ${  PRIMER_APELLIDO_PERSONA}</td>
     <td>${USUARIO_USR}</td>
    <td>${IND_USR}</td>
   <td>${PASSWORD_USR}</td>
   <td>${DES_ROL}</td>
   <td>${ NOM_SUCURSAL}</td>
   
   <td>
   <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
   Actualizar
      </i>
    </button>
     </td>
   </tr>
                  `;
  }); 
  contenedor.innerHTML = resultados;


} catch (error) {
    
}
};

const postUsuarios = async () => {
  try {

    if(codigoPersona.value===""||codigoRol.value===""||descripcionUsuario.value===""||
    nombreUsuario.value===""||estadoUsuario.value===""||contraseñaUsuario.value===""||
    codigoSucursal.value===""){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      codPersona:codigoPersona.value,
      usuario:descripcionUsuario.value,
      ind:estadoUsuario.value,
      contraseña:contraseñaUsuario.value,
      codRol: codigoRol.value,
      codSucursal:codigoSucursal.value 
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        codPersona:codigoPersona.value,
        usuario:descripcionUsuario.value,
        ind:estadoUsuario.value,
        contraseña:contraseñaUsuario.value,
        codRol: codigoRol.value,
        codSucursal:codigoSucursal.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }
};

////////////////////////
const putUsuarios= async () => {
  try {
  
    let body;
  
   
      body = {
        codUsuario:idRegistro,
        usuario:descripcionUsuario.value,
        ind:estadoUsuario.value,
        contraseña:contraseñaUsuario.value,
        codRol: codigoRol.value,
        codSucursal:codigoSucursal.value
        
       
      };
    
     

    console.log(body)
    const requestOptions = {
      method: "PUT",
      body: JSON.stringify(body),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
  location.reload();
  } catch (error) {
    console.log(error.message);
  }
};



const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postUsuarios()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro
on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {
 
    COD_USUARIO,
    COD_PERSONA,
    USUARIO_USR,
    IND_USR,
    PASSWORD_USR,
    COD_ROL,
    COD_SUCURSAL,
  } = JSON.parse(id);

  codigoPersona.value=COD_PERSONA;
  codigoRol.value=COD_ROL;
  descripcionUsuario.value=USUARIO_USR;
  estadoUsuario.value=IND_USR;
  contraseñaUsuario.value=PASSWORD_USR;
  codigoSucursal.value=COD_SUCURSAL;
  idRegistro=COD_USUARIO;

  btnGuardar.innerHTML = `  <button onclick="putUsuarios()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});

const getMarcasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/sucursales");
  const sucursales = await response.json();
  const { data, success } = sucursales;
  const contenedorSelect = document.querySelector("#codigoSucursal");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((sucursal) => {
    const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;

    resultadosSelect += `
 
   <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getRolesSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/roles");
  const roles = await response.json();
  const { data, success } = roles;
  const contenedorSelect = document.querySelector("#codigoRol");
  let resultadosSelect = `<option value="">Por favor elija una Opción</option>`;
  data.forEach((rol) => {
    const { COD_ROL, DES_ROL } = rol;

    resultadosSelect += `
 
   <option value="${COD_ROL}">${DES_ROL}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

const getPersonasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/personas");
  const personas = await response.json();
  const { data, success } = personas;
  const contenedorSelect = document.querySelector("#codigoPersona");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((persona) => {
    const { COD_PERSONA,PRIMER_NOM_PERSONA,	PRIMER_APELLIDO_PERSONA} = persona;

    resultadosSelect += `
 
   <option value="${COD_PERSONA}">${PRIMER_NOM_PERSONA}  ${PRIMER_APELLIDO_PERSONA} </option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};

getMarcasSelect();
getUsuario();
getRolesSelect();
getPersonasSelect();
