let apiUrl = "http://localhost:8082/api/formaPago";

const contenedor = document.querySelector("tbody");

let resultados = "";

  const getFormaPago= async() => {
    try {
      
    
    const response = await fetch(apiUrl);
    const formas = await response.json();
    const { data, success } = formas;
  
    data.forEach((forma) => {
      const {
        COD_FORMA_PAGO,
        DES_FORMA_PAGO,
        NOM_SUCURSAL,
      
       
      } = forma;
  
      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(forma)}</td>
   
      <td>${COD_FORMA_PAGO}</td>
       <td>${DES_FORMA_PAGO}</td>
       

    
     </tr>
                    `;
    }); 
    contenedor.innerHTML = resultados;
  
  
  } catch (error) {
      
  }
  };
  
  

  const getSucursalSelect= async() => {
    try {
      
    const response = await fetch("http://localhost:8082/api/sucursales");
    const sucursales = await response.json();
    const { data, success } = sucursales;
    const contenedorSelect = document.querySelector("#sucursal");
    let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
    data.forEach((sucursal) => {
      const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;
  
      resultadosSelect += `
   
     <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
    
                  `;
    });
    
    contenedorSelect.innerHTML = resultadosSelect;
   
    
  } catch (error) {
      
  }
  };

  getFormaPago();
  getSucursalSelect();