
  let apiUrl = "http://localhost:8082/api/personas";

const contenedor = document.querySelector("tbody");
let idRegistro;
let idF;
let {imgPersona,primerNombre,segundoNombre,primerApellido,segundoApellido,dni,telefono,direccion,email,genero,fechaNacimiento,tipoPersona,tipoTelefono,codigoSucursal} =
document.forms["formularioPersonas"];
const btnGuardar = document.querySelector(".contentBtnGuardar");
let resultados = "";

const getPersonas = async () => {
  try {
    const response = await fetch(apiUrl);
    const personas = await response.json();
    const { data, success } = personas;

    data.forEach((persona) => {
      const {
        COD_PERSONA,
       PRIMER_NOM_PERSONA,
       SEGUNDO_NOM_PERSONA,
       PRIMER_APELLIDO_PERSONA,
       DNI,
       TEL,
       DIR,
       EMAIL,
       GENERO_PERSONA,
       FEC_NAC_PERSONA,
       TIPO_PERSONA,
       TIPO_TELEFONO,
       NOM_SUCURSAL,
       COD_SUCURSAL

      } = persona;

      resultados += `
      <tr>
      <td class="dataItem">${JSON.stringify(persona)}</td>
      <td>${COD_PERSONA}</td>
       <td>${PRIMER_NOM_PERSONA}</td>
       <td>${SEGUNDO_NOM_PERSONA}</td>
       <td>${PRIMER_APELLIDO_PERSONA}</td>
       <td>${DNI}</td>
       <td>${TEL}</td>
       <td>${DIR}</td>
       <td>${EMAIL}</td>
       <td>${GENERO_PERSONA}</td>
       <td>${FEC_NAC_PERSONA}</td>
       <td>${TIPO_PERSONA}</td>
       <td>${TIPO_TELEFONO}</td>
       <td>${NOM_SUCURSAL}</td>
     <td>
     <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
     Actualizar
        </i>
      </button>
       </td>
     </tr>
                    `;
                  });

                  contenedor.innerHTML = resultados;
                } catch (error) {
                  console.log(error);
                }
              };

const postPersonas= async () => {
  try {

    if(imgPersona.value===""||primerNombre.value===""||segundoNombre.value===""||
    primerApellido.value===""||segundoApellido.value===""||dni.value===""||telefono.value===""||
    direccion.value===""||email.value===""||genero.value===""||fechaNacimiento.value===""||
    tipoPersona.value===""||tipoTelefono.value===""||codigoSucursal.value==="" ){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      imgPersonas:imgPersona.value,
      primerNombre:primerNombre.value,
      segundoNombre:segundoNombre.value,
      primerApellido:primerApellido.value,
      segundoApellido:segundoApellido.value,
      dni:dni.value,
      tel:telefono.value,
      tipoTelefono:tipoTelefono.value,
      dir:direccion.value,
      email:email.value,
      genero:genero.value,
      fechaNacimiento:fechaNacimiento.value,
      tipoPersona:tipoPersona.value,
      codSucursal:codigoSucursal.value
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        imgPersonas:imgPersona.value,
        primerNombre:primerNombre.value,
        segundoNombre:segundoNombre.value,
        primerApellido:primerApellido.value,
        segundoApellido:segundoApellido.value,
        dni:dni.value,
        tel:telefono.value,
        tipoTelefono:tipoTelefono.value,
        dir:direccion.value,
        email:email.value,
        genero:genero.value,
        fechaNacimiento:fechaNacimiento.value,
        tipoPersona:tipoPersona.value,
        codSucursal:codigoSucursal.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }

};


const putPersonas= async () => {
  try {

    let body;
      body = {
        codPersona:idRegistro,
        imgPersonas:imgPersona.value,
        primerNombre:primerNombre.value,
        segundoNombre:segundoNombre.value,
        primerApellido:primerApellido.value,
        segundoApellido:segundoApellido.value,
        dni:dni.value,
        tel:telefono.value,
        dir:direccion.value,
        email:email.value,
        genero:genero.value,
        fechaNacimiento:idF,
        tipoPersona:tipoPersona.value,
        tipoTelefono:tipoTelefono.value
  
       
      };
    
     

    console.log(body)
    const requestOptions = {
      method: "PUT",
      body: JSON.stringify(body),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
 // location.reload();
  } catch (error) {
    console.log(error.message);
  }
};



const on = (element, event, selector, handler) => {
  element.addEventListener(event, (e) => {
    if (e.target.closest(selector)) {
      handler(e);
    }
  });

};
on(document, "click", ".btnGuardar", (e) => {
 
  //descripcionMarca.value = "";

  btnGuardar.innerHTML = ` <button onclick="postPersonas()"
                                             type="button"
                                             class="btn btn-default button-template-add-form">Guardar
                            </button>`;
});
// editar registro
on(document, "click", ".btnEditar", (e) => {
  const fila = e.target.parentNode.parentNode;
  const id = fila.firstElementChild.innerHTML;

  console.log(id)
  const {

    COD_PERSONA,
    IMG_PERSONA,
       PRIMER_NOM_PERSONA,
       SEGUNDO_NOM_PERSONA,
       PRIMER_APELLIDO_PERSONA,
       SEGUNDO_APELLIDO_PERSONA,
       DNI,
       TEL,
       DIR,
       EMAIL,
       GENERO_PERSONA,
       FEC_NAC_PERSONA,
       TIPO_PERSONA,
       TIPO_TELEFONO,
       COD_SUCURSAL,
  } = JSON.parse(id);
  

    idRegistro=COD_PERSONA;
    idF=FEC_NAC_PERSONA;
  imgPersona.value=IMG_PERSONA;
  primerNombre.value=PRIMER_NOM_PERSONA;
  segundoNombre.value=SEGUNDO_NOM_PERSONA;
  primerApellido.value=PRIMER_APELLIDO_PERSONA;
  segundoApellido.value=SEGUNDO_APELLIDO_PERSONA;
  dni.value=DNI;
  telefono.value=TEL;
  direccion.value=DIR;
  email.value=EMAIL;
  genero.value=GENERO_PERSONA;
  fechaNacimiento.value=FEC_NAC_PERSONA;
  tipoPersona.value=TIPO_PERSONA;
  tipoTelefono.value=TIPO_TELEFONO;
  codigoSucursal.value=COD_SUCURSAL;

  btnGuardar.innerHTML = `  <button onclick="putPersonas()"
                                type="button"
                                class="btn btn-default button-template-add-form">Actualizar
                            </button>`;

});


const getPersonasSelect= async() => {
  try {
    
  const response = await fetch("http://localhost:8082/api/sucursales");
  const sucursales = await response.json();
  const { data, success } = sucursales;
  const contenedorSelect = document.querySelector("#codigoSucursal");
  let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
  data.forEach((sucursal) => {
    const { COD_SUCURSAL, NOM_SUCURSAL } = sucursal;

    resultadosSelect += `
 
   <option value="${COD_SUCURSAL}">${NOM_SUCURSAL}</option>
  
                `;
  });
  
  contenedorSelect.innerHTML = resultadosSelect;
 
  
} catch (error) {
    
}
};
getPersonas();
getPersonasSelect();

