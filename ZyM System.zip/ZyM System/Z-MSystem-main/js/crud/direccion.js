let apiUrl = "http://localhost:8082/api/direccion";

  const contenedor = document.querySelector("tbody");
  let {descripcionDireccion,nombrePersona } =
  document.forms["formularioDireccion"];
  
  let resultados = "";
  
  const getDireccion = async () => {
    try {
      const response = await fetch(apiUrl);
      const direcciones = await response.json();
      const { data, success } = direcciones;
  
      data.forEach((direccion) => {
        const {
          COD_DIR,
          DES_DIR,
          PRIMER_NOM_PERSONA, PRIMER_APELLIDO_PERSONA,
          COD_PERSONA,
        } = direccion;
  
        resultados += `
        <tr>
        <td class="dataItem">${JSON.stringify(direccion)}</td>
         <td>${COD_DIR}</td>
     <td>${DES_DIR}</td>
       <td>${PRIMER_NOM_PERSONA } ${ PRIMER_APELLIDO_PERSONA}</td>
       <td>
       <button type="button" class="btnEditar btn button-template-add" data-toggle="modal" data-target="#myModal">
     Actualizar
        </i>
      </button>
         </td>
       </tr>
                      `;
      });
  
      contenedor.innerHTML = resultados;
    } catch (error) {
      console.log(error);
    }
  };
  
  
  const postDireccion = async () => {
    
  try {

    if( descripcionDireccion.value==="" || nombrePersona.value===""){
      alertify.alert("No, se permiten campos Vacíos", function () { });
    
    }else{ 
       await firebase
       
    console.log("hola",{
      desDireccion:descripcionDireccion.value,
      codPersona:nombrePersona.value
      
    })
    const requestOptions = {
      method: "POST",
      body: JSON.stringify({
        desDireccion:descripcionDireccion.value,
        codPersona:nombrePersona.value
        
      }),
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    const response = await fetch(apiUrl, requestOptions);
    const data = await response.json();
    console.log(data);
    location.reload();
       
        setTimeout(() => {
          location.reload();
        }, 3000);
      }

  } catch (error) {
    console.log(error);
  }
 };


  const getPersonasSelect= async() => {
    try {
      
    const response = await fetch("http://localhost:8082/api/personas");
    const personas = await response.json();
    const { data, success } = personas;
    const contenedorSelect = document.querySelector("#nombrePersona");
    let resultadosSelect = `<option value="">Por favor elija una pción</option>`;
    data.forEach((persona) => {
      const { COD_PERSONA,PRIMER_NOM_PERSONA,	PRIMER_APELLIDO_PERSONA} = persona;
  
      resultadosSelect += `
   
     <option value="${COD_PERSONA}">${PRIMER_NOM_PERSONA}  ${PRIMER_APELLIDO_PERSONA} </option>
    
                  `;
    });
    
    contenedorSelect.innerHTML = resultadosSelect;
   
    
  } catch (error) {
      
  }
  };
  


  const putDireccion= async (id = null, estado = null) => {
    try {
  
      console.log(idRegistro)
      let body;
      if (id) {
        const {
          COD_DIR,
          DES_DIR,
          PRIMER_NOM_PERSONA, PRIMER_APELLIDO_PERSONA,
        } = JSON.parse(id);
  
        body = {
          codDireccion:idRegistro,
          desDireccion:descripcionDireccion.value,
          codPersona:nombrePersona.value, 
        
  
        
        };
      } else {
        body = {
          codDireccion:idRegistro,
          desDireccion:descripcionDireccion.value,
          codPersona:nombrePersona.value, 
        
        };
      }
  
      console.log(body)
      const requestOptions = {
        method: "PUT",
        body: JSON.stringify(body),
        headers: { "Content-type": "application/json; charset=UTF-8" },
      };
  
      const response = await fetch(apiUrl, requestOptions);
      const data = await response.json();
      console.log(data);
     location.reload();
    } catch (error) {
      console.log(error.message);
    }
  };
  
  
  
  const on = (element, event, selector, handler) => {
    element.addEventListener(event, (e) => {
      if (e.target.closest(selector)) {
        handler(e);
      }
    });
  
  };
  on(document, "click", ".btnGuardar", (e) => {
   
    //descripcionMarca.value = "";
  
    btnGuardar.innerHTML = ` <button onclick="postDireccion()"
                                               type="button"
                                               class="btn btn-default button-template-add-form">Guardar
                              </button>`;
  });
  // editar registro
  on(document, "click", ".btnEditar", (e) => {
    const fila = e.target.parentNode.parentNode;
    const id = fila.firstElementChild.innerHTML;
  
    console.log(id)
    const {
      COD_DIR,
      DES_DIR,
     COD_PERSONA,

    } = JSON.parse(id);
    descripcionDireccion.value=DES_DIR,
    nombrePersona.value=COD_PERSONA,
    idRegistro=COD_DIR
  
  
    btnGuardar.innerHTML = `  <button onclick="putDireccion()"
                                  type="button"
                                  class="btn btn-default button-template-add-form">Actualizar
                              </button>`;
  
  });





  getDireccion();
  getPersonasSelect();